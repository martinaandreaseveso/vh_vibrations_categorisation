#supplementary materials
install.packages("MuMIn")
library(MuMIn)
library(performance)

#####Synch assesment####
#100b
pm_finaldata <- synch_ass_100B
#descriptive statistics
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
pm_finaldata$percevied_sync
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)
"  SOA        mean    sd     n
  <fct>     <dbl> <dbl> <int>
1 0ms SOA    3.66  1.34   165
2 150ms SOA  3.24  1.41   163
3 300ms SOA  3.08  1.46   158"
# Check for normality of residuals
# Fit a linear model
model <- lm(percevied_sync ~ SOA, data = pm_finaldata)
# Shapiro-Wilk test for normality of residuals - violated
shapiro_test <- shapiro.test(residuals(model))
print(shapiro_test)
"	Shapiro-Wilk normality test

data:  residuals(model)
W = 0.90973, p-value < 2.2e-16"
# check for homogeneity of variances - violated
levene_test <- leveneTest(percevied_sync ~ SOA, data = pm_finaldata)
print(levene_test)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value Pr(>F)  
group   2  3.8468  0.022 *
      483        "
summary_stats <- pm_finaldata %>%
  group_by(ID,SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

welch_result <- oneway.test(mean ~ SOA, data = summary_stats, var.equal = FALSE)
print(welch_result)
"One-way analysis of means (not assuming equal variances)

data:  mean and SOA
F = 6.1174, num df = 2.000, denom df = 86.866, p-value = 0.003269"
#post hoc
install.packages("PMCMRplus")
library(PMCMRplus)
games_howell <- gamesHowellTest(mean ~ SOA, data = summary_stats)
print(games_howell)
"Pairwise comparisons using Games-Howell test - data: mean by SOA
          0ms SOA 150ms SOA
150ms SOA 0.0163  -        
300ms SOA 0.0052  0.6974   

No offset vs. 150ms offset: p=0.0163 
No offset vs. 300ms offset: p= 0.0052
150ms offset vs. 300ms offset: p=0.6974"

#structure of summary_stats:
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync, na.rm = TRUE),
    sd = sd(percevied_sync, na.rm = TRUE),
    n = n(),
    se = sd / sqrt(n),  # Standard Error
    ci = qt(0.975, df = n - 1) * se  # 95% Confidence Interval
  )
ps_100B <- ggplot(summary_stats, aes(x = SOA, y = mean, fill = SOA)) +
  geom_point(alpha = 0.8) +  # If you want bars
  geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = 0.2, color = "black") +  # Add 95% CI
  stat_summary(geom = "point", size = 4, shape = 21) +  # Add summary points
  theme_apa()+
  labs(
    title = "A)",
    x = "SOA Levels",
    y = "Perceived Synchrony"
  ) +
  ylim(2,5)+
  annotate("text", x = 1.5, y = max(summary_stats$mean) + 0.5, label = "**", size = 5, color = "black") +  # No offset vs. 150ms offset
  annotate("text", x = 2, y = max(summary_stats$mean) + 1, label = "***", size = 5, color = "black") +    # No offset vs. 300ms offset
  annotate("text", x = 2.5, y = max(summary_stats$mean) + 0.2, label = "ns", size = 4, color = "black")   # 150ms offset vs. 300ms offset
ps_100B
ggsave('ps_100B.jpg', ps_100B, width = 6, height = 6, dpi = 300)

#100i
pm_finaldata <- synch_ass_100I
colnames(pm_finaldata)[7] <- 'SOA'
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
levels(pm_finaldata$SOA)<- c("150ms SOA", "300ms SOA", "0ms SOA")
pm_finaldata$SOA <- factor(pm_finaldata$SOA, levels=c("0ms SOA","150ms SOA", "300ms SOA"))

#descriptive statistics
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
pm_finaldata$percevied_sync
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)
" SOA        mean    sd     n
  <fct>     <dbl> <dbl> <int>
1 0ms SOA    3.70  1.23   118
2 150ms SOA  2.90  1.41   113
3 300ms SOA  2.98  1.36   118"
# Check for normality of residuals
# Fit a linear model
model <- lm(percevied_sync ~ SOA, data = pm_finaldata)
# Shapiro-Wilk test for normality of residuals - violated
shapiro_test <- shapiro.test(residuals(model))
print(shapiro_test)
"	Shapiro-Wilk normality test

data:  residuals(model)
W = 0.93674, p-value = 4.972e-11"
# check for homogeneity of variances - violated
levene_test <- leveneTest(percevied_sync ~ SOA, data = pm_finaldata)
print(levene_test)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value   Pr(>F)   
group   2   4.722 0.009479 **
      346"
summary_stats <- pm_finaldata %>%
  group_by(ID,SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

welch_result <- oneway.test(mean ~ SOA, data = summary_stats, var.equal = FALSE)
print(welch_result)
"	One-way analysis of means (not assuming equal variances)

data:  mean and SOA
F = 13.536, num df = 2.000, denom df = 61.827, p-value = 1.331e-05"
#post hoc
library(PMCMRplus)
games_howell <- gamesHowellTest(mean ~ SOA, data = summary_stats)
print(games_howell)
"Pairwise comparisons using Games-Howell test - data: mean by SOA
           0ms SOA 150ms SOA
150ms SOA 2.1e-05 -        
300ms SOA 0.0003  0.8348"

#structure of summary_stats:
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync, na.rm = TRUE),
    sd = sd(percevied_sync, na.rm = TRUE),
    n = n(),
    se = sd / sqrt(n),  # Standard Error
    ci = qt(0.975, df = n - 1) * se  # 95% Confidence Interval
  )
ps_100I <- ggplot(summary_stats, aes(x = SOA, y = mean, fill = SOA)) +
  geom_point(alpha = 0.8) +  # If you want bars
  geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = 0.2, color = "black") +  # Add 95% CI
  stat_summary(geom = "point", size = 4, shape = 21) +  # Add summary points
  theme_apa()+
  labs(
    title = "B)",
    x = "SOA Levels",
    y = "Perceived Synchrony"
  ) +
  ylim(2,5)+
  annotate("text", x = 1.5, y = max(summary_stats$mean) + 0.5, label = "***", size = 5, color = "black") +  # No offset vs. 150ms offset
  annotate("text", x = 2, y = max(summary_stats$mean) + 1, label = "***", size = 5, color = "black") +    # No offset vs. 300ms offset
  annotate("text", x = 2.5, y = max(summary_stats$mean) + 0.2, label = "ns", size = 4, color = "black")   # 150ms offset vs. 300ms offset
ps_100I
ggsave('ps_100I.jpg', ps_100I, width = 6, height = 6, dpi = 300)

#78b
pm_finaldata <- synch_ass_78B
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
levels(pm_finaldata$SOA)
pm_finaldata$SOA <- factor(pm_finaldata$SOA, levels=c("No SOA","150ms SOA", "300ms SOA"))
levels(pm_finaldata$SOA) <- c("0ms SOA","150ms SOA", "300ms SOA")
#descriptive statistics
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
pm_finaldata$percevied_sync
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)
" SOA        mean    sd     n
  <fct>     <dbl> <dbl> <int>
1 0ms SOA    3.63  1.23   115
2 150ms SOA  3.18  1.46   115
3 300ms SOA  2.97  1.43   116"
# Check for normality of residuals
# Fit a linear model
model <- lm(percevied_sync ~ SOA, data = pm_finaldata)
# Shapiro-Wilk test for normality of residuals - violated
shapiro_test <- shapiro.test(residuals(model))
print(shapiro_test)
"	Shapiro-Wilk normality test

data:  residuals(model)
W = 0.93013, p-value = 1.182e-11"
# check for homogeneity of variances - violated
levene_test <- leveneTest(percevied_sync ~ SOA, data = pm_finaldata)
print(levene_test)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value    Pr(>F)    
group   2  8.1742 0.0003404 ***
      343"
summary_stats <- pm_finaldata %>%
  group_by(ID,SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

welch_result <- oneway.test(mean ~ SOA, data = summary_stats, var.equal = FALSE)
print(welch_result)
"		One-way analysis of means (not assuming equal variances)

data:  mean and SOA
F = 5.7964, num df = 2.000, denom df = 63.881, p-value = 0.004861"
#post hoc
library(PMCMRplus)
games_howell <- gamesHowellTest(mean ~ SOA, data = summary_stats)
print(games_howell)
"          0ms SOA 150ms SOA
150ms SOA 0.0780  -        
300ms SOA 0.0034  0.4564   "

#structure of summary_stats:
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync, na.rm = TRUE),
    sd = sd(percevied_sync, na.rm = TRUE),
    n = n(),
    se = sd / sqrt(n),  # Standard Error
    ci = qt(0.975, df = n - 1) * se  # 95% Confidence Interval
  )
ps_78B <- ggplot(summary_stats, aes(x = SOA, y = mean, fill = SOA)) +
  geom_point(alpha = 0.8) +  # If you want bars
  geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = 0.2, color = "black") +  # Add 95% CI
  stat_summary(geom = "point", size = 4, shape = 21) +  # Add summary points
  theme_apa()+
  labs(
    title = "C)",
    x = "SOA Levels",
    y = "Perceived Synchrony"
  ) +
  ylim(2,5)+
  annotate("text", x = 1.5, y = max(summary_stats$mean) + 0.5, label = "ns", size = 5, color = "black") +  # No offset vs. 150ms offset
  annotate("text", x = 2, y = max(summary_stats$mean) + 1, label = "***", size = 5, color = "black") +    # No offset vs. 300ms offset
  annotate("text", x = 2.5, y = max(summary_stats$mean) + 0.2, label = "ns", size = 4, color = "black")   # 150ms offset vs. 300ms offset
ps_78B
ggsave('ps_78B.jpg', ps_78B, width = 6, height = 6, dpi = 300)

#78i
pm_finaldata <- sync_ass_78I
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
levels(pm_finaldata$SOA)
#descriptive statistics
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
pm_finaldata$percevied_sync
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)
"  SOA        mean    sd     n
  <fct>     <dbl> <dbl> <int>
1 0ms SOA    3.62  1.28   112
2 150ms SOA  3.10  1.44   118
3 300ms SOA  3.14  1.47   117"
# Check for normality of residuals
# Fit a linear model
model <- lm(percevied_sync ~ SOA, data = pm_finaldata)
# Shapiro-Wilk test for normality of residuals - violated
shapiro_test <- shapiro.test(residuals(model))
print(shapiro_test)
"		Shapiro-Wilk normality test

data:  residuals(model)
W = 0.92292, p-value = 2.244e-12"
# check for homogeneity of variances - violated
levene_test <- leveneTest(percevied_sync ~ SOA, data = pm_finaldata)
print(levene_test)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value   Pr(>F)   
group   2  6.3862 0.001891 **
      344  "
summary_stats <- pm_finaldata %>%
  group_by(ID,SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

welch_result <- oneway.test(mean ~ SOA, data = summary_stats, var.equal = FALSE)
print(welch_result)
"		One-way analysis of means (not assuming equal variances)

data:  mean and SOA
F = 4.823, num df = 2.000, denom df = 63.969, p-value = 0.0112"
#post hoc
library(PMCMRplus)
games_howell <- gamesHowellTest(mean ~ SOA, data = summary_stats)
print(games_howell)
"           0ms SOA 150ms SOA
150ms SOA 0.024   -        
300ms SOA 0.025   0.999 "

#structure of summary_stats:
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync, na.rm = TRUE),
    sd = sd(percevied_sync, na.rm = TRUE),
    n = n(),
    se = sd / sqrt(n),  # Standard Error
    ci = qt(0.975, df = n - 1) * se  # 95% Confidence Interval
  )
ps_78I <- ggplot(summary_stats, aes(x = SOA, y = mean, fill = SOA)) +
  geom_point(alpha = 0.8) +  # If you want bars
  geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = 0.2, color = "black") +  # Add 95% CI
  stat_summary(geom = "point", size = 4, shape = 21) +  # Add summary points
  theme_apa()+
  labs(
    title = "D)",
    x = "SOA Levels",
    y = "Perceived Synchrony"
  ) +
  ylim(2,5)+
  annotate("text", x = 1.5, y = max(summary_stats$mean) + 0.5, label = "**", size = 5, color = "black") +  # No offset vs. 150ms offset
  annotate("text", x = 2, y = max(summary_stats$mean) + 1, label = "**", size = 5, color = "black") +    # No offset vs. 300ms offset
  annotate("text", x = 2.5, y = max(summary_stats$mean) + 0.2, label = "ns", size = 4, color = "black")   # 150ms offset vs. 300ms offset
ps_78I
ggsave('ps_78I.jpg', ps_78I, width = 6, height = 6, dpi = 300)

#100b_ls
pm_finaldata <- synchr_ass_100B_LS
colnames(pm_finaldata)[2] <- 'SOA'
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
levels(pm_finaldata$SOA) <- c("150ms SOA", "300ms SOA", "0ms SOA")
pm_finaldata$SOA <- factor(pm_finaldata$SOA, levels=c("0ms SOA","150ms SOA", "300ms SOA"))

#descriptive statistics
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
pm_finaldata$percevied_sync
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)
" SOA        mean    sd     n
  <fct>     <dbl> <dbl> <int>
1 0ms SOA    3.65  1.25   119
2 150ms SOA  3.18  1.33   113
3 300ms SOA  3.07  1.38   116"
# Check for normality of residuals
# Fit a linear model
model <- lm(percevied_sync ~ SOA, data = pm_finaldata)
# Shapiro-Wilk test for normality of residuals - violated
shapiro_test <- shapiro.test(residuals(model))
print(shapiro_test)
"	Shapiro-Wilk normality test

data:  residuals(model)
W = 0.93302, p-value = 2.116e-11"
# check for homogeneity of variances - violated
levene_test <- leveneTest(percevied_sync ~ SOA, data = pm_finaldata)
print(levene_test)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value  Pr(>F)  
group   2  2.5316 0.08101 .
      345           "
summary_stats <- pm_finaldata %>%
  group_by(ID,SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

welch_result <- oneway.test(mean ~ SOA, data = summary_stats, var.equal = FALSE)
print(welch_result)
"	One-way analysis of means (not assuming equal variances)

data:  mean and SOA
F = 5.6235, num df = 2.000, denom df = 61.755, p-value = 0.00570"
#post hoc
library(PMCMRplus)
games_howell <- gamesHowellTest(mean ~ SOA, data = summary_stats)
print(games_howell)
"Pairwise comparisons using Games-Howell test - data: mean by SOA
          0ms SOA 150ms SOA
150ms SOA 0.0253  -        
300ms SOA 0.0061  0.8018 "

#structure of summary_stats:
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync, na.rm = TRUE),
    sd = sd(percevied_sync, na.rm = TRUE),
    n = n(),
    se = sd / sqrt(n),  # Standard Error
    ci = qt(0.975, df = n - 1) * se  # 95% Confidence Interval
  )
ps_100B_LS <- ggplot(summary_stats, aes(x = SOA, y = mean, fill = SOA)) +
  geom_point(alpha = 0.8) +  # If you want bars
  geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = 0.2, color = "black") +  # Add 95% CI
  stat_summary(geom = "point", size = 4, shape = 21) +  # Add summary points
  theme_apa()+
  labs(
    title = "E)",
    x = "SOA Levels",
    y = "Perceived Synchrony"
  ) +
  ylim(2,5)+
  annotate("text", x = 1.5, y = max(summary_stats$mean) + 0.5, label = "***", size = 5, color = "black") +  # No offset vs. 150ms offset
  annotate("text", x = 2, y = max(summary_stats$mean) + 1, label = "***", size = 5, color = "black") +    # No offset vs. 300ms offset
  annotate("text", x = 2.5, y = max(summary_stats$mean) + 0.2, label = "ns", size = 4, color = "black")   # 150ms offset vs. 300ms offset
ps_100B_LS
ggsave('ps_100B_LS.jpg', ps_100B_LS, width = 6, height = 6, dpi = 300)

"100B
model2_noint
test_filtered_dataset_100_B"
"100R
model3_noint_r
test_filtered_dataset_100_R"
"78B
model3_78b
test_filtered_dataset_78_B"
"78R
model5_no_int_78r_2
test_filtered_dataset_78_R"
"100BLS
correct_model_100LS
acc_data_LS"

####Table s3####
##Accuracy-glmer###
"100B
model2_noint
test_filtered_dataset_100_B"
r2_values <- r.squaredGLMM(model2_noint)
print(r2_values)
"                   R2m       R2c
theoretical 0.06024279 0.4493111
delta       0.05370962 0.4005845"
# glmer (accuracy, binomial), calculate predicted probabilities and residuals:
predicted <- predict(model2_noint, type = "response")
observed <- model2_noint@frame$accuracy  # or your DV variable name
# calculate RMSE manually
rmse_value <- sqrt(mean((observed - predicted)^2))
print(rmse_value)
"0.3925564"

"100R
model3_noint_r
test_filtered_dataset_100_R"
r2_values <- r.squaredGLMM(model3_noint_r)
print(r2_values)
"                  R2m       R2c
theoretical 0.01446888 0.3267656
delta       0.01246668 0.2815477"
#  glmer (accuracy, binomial), calculate predicted probabilities and residuals:
predicted <- predict(model3_noint_r, type = "response")
observed <- model3_noint_r@frame$accuracy  # or your DV variable name
# calculate RMSE manually
rmse_value <- sqrt(mean((observed - predicted)^2))
print(rmse_value)
" 0.4402966"

"78B
model3_78b
test_filtered_dataset_78_B"
r2_values <- r.squaredGLMM(model3_78b)
print(r2_values)
"                 R2m       R2c
theoretical 0.1652019 0.5610145
delta       0.1501965 0.5100571"
#  glmer (accuracy, binomial), calculate predicted probabilities and residuals:
predicted <- predict(model3_78b, type = "response")
observed <- model3_78b@frame$accuracy  # or your DV variable name
# calculate RMSE manually
rmse_value <- sqrt(mean((observed - predicted)^2))
print(rmse_value)
" 0.3665562"

"78R
model5_no_int_78r_2
test_filtered_dataset_78_R"
r2_values <- r.squaredGLMM(model5_no_int_78r_2)
print(r2_values)
"                   R2m       R2c
theoretical 0.04925113 0.1649087
delta       0.03858251 0.1291867"
#  glmer (accuracy, binomial), calculate predicted probabilities and residuals:
predicted <- predict(model5_no_int_78r_2, type = "response")
observed <- model5_no_int_78r_2@frame$accuracy  # or your DV variable name
# calculate RMSE manually
rmse_value <- sqrt(mean((observed - predicted)^2))
print(rmse_value)
"0.4550712"

"100BLS
correct_model_100LS
acc_data_LS"
r2_values <- r.squaredGLMM(correct_model_100LS)
print(r2_values)
"> print(r2_values)
                  R2m       R2c
theoretical 0.1209165 0.5510484
delta       0.1102042 0.5022295"
#  glmer (accuracy, binomial), calculate predicted probabilities and residuals:
predicted <- predict(correct_model_100LS, type = "response")
observed <- correct_model_100LS@frame$accuracy  # or your DV variable name
# calculate RMSE manually
rmse_value <- sqrt(mean((observed - predicted)^2))
print(rmse_value)
"0.3118591"

##RTs -------
####100_B####
data_lmer_RT <- RTtest_data_filtered_100_B 
#prep dataset for models
data_lmer_RT$ID <- factor(data_lmer_RT$ID)
data_lmer_RT$exemplar <- as.factor(data_lmer_RT$exemplar)
levels(data_lmer_RT$exemplar)
data_lmer_RT$exemplar <- factor(data_lmer_RT$exemplar, levels = c("Not learned", "Learned"))
data_lmer_RT$task <- as.factor(data_lmer_RT$task)
levels(data_lmer_RT$task) <- c("Shape", "Shape + Tactile Motion","Shape + Visual Motion", "Shape + Motion + Tactile")
data_lmer_RT$task <- factor(data_lmer_RT$task, levels = c("Shape", "Shape + Visual Motion","Shape + Tactile Motion", "Shape + Motion + Tactile"))

model1_rt<-lmer(RTms ~ task*exemplar + 
                  task + exemplar+
                  (1|ID), 
                data = data_lmer_RT)
summary(model1_rt)
model1_rt_noint <-lmer(RTms ~ task + exemplar+
                         (1|ID), 
                       data = data_lmer_RT)
summary(model1_rt_noint)
anova(model1_rt,model1_rt_noint)
"                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_rt_noint    7 149640 149690 -74813    149626                     
model1_rt         10 149645 149717 -74813    149625 0.6571  3     0.8832"
#main effects
model1_noint2 <-lmer(RTms ~ task +
                       (1|ID), 
                     data = data_lmer_RT)
summary(model1_noint2)
anova(model1_rt_noint, model1_noint2)
"EXEMPLAR MAIN EFFECT - SIGNIFICANT
                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model1_noint2      6 149654 149697 -74821    149642                         
model1_rt_noint    7 149640 149690 -74813    149626 15.915  1  6.624e-05 ***"
"CONDITON MAIN EFFECT
                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model1_noint2      4 151876 151905 -75934    151868                         
model1_rt_noint    7 149640 149690 -74813    149626 2242.6  3  < 2.2e-16 ***"
#posthoc values
post_learn = emmeans(model1_rt_noint, pairwise~exemplar, type = 'response', adjust = 'bonferroni')
post_learn = emmeans(model1_rt_noint, pairwise ~ exemplar, type = 'response', 
                     adjust = 'bonferroni', 
                     lmerTest.limit = 9609, pbkrtest.limit = 9609)
results_learn <- post_learn$contrasts %>% rbind()
results_learn
"TASK
contrast                                              estimate   SE  df z.ratio p.value
 Shape - (Shape + Visual Motion)                           -245 16.7 Inf -14.696  <.0001
 Shape - (Shape + Tactile Motion)                          -739 16.8 Inf -44.001  <.0001
 Shape - (Shape + Motion + Tactile)                        -635 16.7 Inf -38.039  <.0001
 (Shape + Visual Motion) - (Shape + Tactile Motion)        -494 16.6 Inf -29.770  <.0001
 (Shape + Visual Motion) - (Shape + Motion + Tactile)      -390 16.5 Inf -23.646  <.0001
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)      104 16.6 Inf   6.257  <.0001

EXEMPLAR
contrast              estimate   SE   df t.ratio p.value
 Not learned - Learned       49 12.3 9560   3.990  0.0001"
results_CI_learn <-
  confint(results_learn)
results_CI_learn
#CI
"contrast                                              estimate   SE  df asymp.LCL asymp.UCL
 Shape - (Shape + Visual Motion)                           -245 16.7 Inf    -289.3      -201
 Shape - (Shape + Tactile Motion)                          -739 16.8 Inf    -783.4      -695
 Shape - (Shape + Motion + Tactile)                        -635 16.7 Inf    -679.3      -591
 (Shape + Visual Motion) - (Shape + Tactile Motion)        -494 16.6 Inf    -537.6      -450
 (Shape + Visual Motion) - (Shape + Motion + Tactile)      -390 16.5 Inf    -433.5      -346
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)      104 16.6 Inf      60.1       148
 
 contrast              estimate   SE   df lower.CL upper.CL
 Not learned - Learned       49 12.3 9560     24.9     73.1
"

model1_RTS<- plot_model(model1_rt_noint)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_RTS
ggsave("rts_model_oddratio_100B.png", model1_RTS, width= 5, height = 4, dpi = 300)

plot_lmer_rts<- plot_model(model1_rt_noint, type = "eff", terms = c("task")) +
  theme_apa()+
  labs(x ="Cue Condition",y="Predicted Reaction Time (ms)", title= "C)")+
  ylim(c(500,2000))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_rts
ggsave('model_RT_100Btask.jpg', plot_lmer_rts, width = 4, height = 4 , dpi = 300)
ggsave('model_RT_100Btexp.jpg', plot_lmer_rts, width = 4, height = 4 , dpi = 300)

#check the plot predicted values
ggeffect(model1_rt_noint, terms = c("task"), type = 'fe')
"task                     | Predicted |           95% CI
-------------------------------------------------------
Shape                    |   1020.77 |  909.69, 1131.85
Shape + Visual Motion    |   1266.04 | 1155.08, 1377.00
Shape + Tactile Motion   |   1759.84 | 1648.82, 1870.85
Shape + Motion + Tactile |   1656.00 | 1545.04, 1766.96"
"exemplar    | Predicted |           95% CI
------------------------------------------
Not learned |   1459.67 | 1349.38, 1569.96
Learned     |   1410.65 | 1301.13, 1520.18"

####100_R####
data_lmer_RT <- RTtest_filtered_dataset_100_R
data_lmer_RT$ID <- factor(data_lmer_RT$ID)
data_lmer_RT$exemplar <- as.factor(data_lmer_RT$exemplar)
levels(data_lmer_RT$exemplar)
data_lmer_RT$exemplar <- factor(data_lmer_RT$exemplar, levels = c("Not learned", "Learned"))
data_lmer_RT$task <- as.factor(data_lmer_RT$task)
levels(data_lmer_RT$task) <- c("Shape", "Shape + Tactile Motion","Shape + Visual Motion", "Shape + Motion + Tactile")
data_lmer_RT$task <- factor(data_lmer_RT$task, levels = c("Shape", "Shape + Visual Motion","Shape + Tactile Motion", "Shape + Motion + Tactile"))

model1_rt<-lmer(RTms ~ task*exemplar + 
                  task + exemplar+
                  (1|ID), 
                data = data_lmer_RT)
summary(model1_rt)
model1_rt_noint <-lmer(RTms ~ task + exemplar+
                         (1|ID), 
                       data = data_lmer_RT)
summary(model1_rt_noint)
anova(model1_rt,model1_rt_noint)
"                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_rt_noint    7 102927 102974 -51456    102913                     
model1_rt         10 102932 103000 -51456    102912 0.8969  3     0.8262"
#main effects
model1_noint2 <-lmer(RTms ~ task +
                       (1|ID), 
                     data = data_lmer_RT)
summary(model1_noint2)
anova(model1_rt_noint, model1_noint2)
"EXEMPLAR MAIN EFFECT - NO SIGNIFICANT
                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_noint2      6 102925 102966 -51457    102913                     
model1_rt_noint    7 102927 102974 -51456    102913 0.5553  1     0.4561"
"CONDITON MAIN EFFECT
               npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model1_noint2      4 102939 102966 -51465    102931                         
model1_rt_noint    7 102927 102974 -51456    102913 17.872  3  0.0004674 ***"
#posthoc values
post_learn = emmeans(model1_noint2, pairwise ~ task, type = 'response', 
                     adjust = 'bonferroni', 
                     lmerTest.limit = 9609, pbkrtest.limit = 9609)
results_learn <- post_learn$contrasts %>% rbind()
results_learn
"TASK
contrast                                              estimate   SE   df t.ratio p.value
 Shape - (Shape + Visual Motion)                         -45.60 20.0 6593  -2.285  0.1341
 Shape - (Shape + Tactile Motion)                         -1.65 19.9 6594  -0.083  1.0000
 Shape - (Shape + Motion + Tactile)                       36.41 19.8 6594   1.838  0.3965
 (Shape + Visual Motion) - (Shape + Tactile Motion)       43.95 19.5 6592   2.251  0.1464
 (Shape + Visual Motion) - (Shape + Motion + Tactile)     82.00 19.4 6592   4.222  0.0001
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)    38.05 19.4 6592   1.966  0.2958"
results_CI_learn <-
  confint(results_learn)
results_CI_learn
#CI
" contrast                                              estimate   SE   df lower.CL upper.CL
 Shape - (Shape + Visual Motion)                         -45.60 20.0 6593   -98.26     7.06
 Shape - (Shape + Tactile Motion)                         -1.65 19.9 6594   -54.18    50.88
 Shape - (Shape + Motion + Tactile)                       36.41 19.8 6594   -15.86    88.67
 (Shape + Visual Motion) - (Shape + Tactile Motion)       43.95 19.5 6592    -7.57    95.46
 (Shape + Visual Motion) - (Shape + Motion + Tactile)     82.00 19.4 6592    30.74   133.26
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)    38.05 19.4 6592   -13.02    89.13"

model1_RTS<- plot_model(model1_noint2)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_RTS
ggsave("rts_model_oddratio_10R.png", model1_RTS, width = 5, height = 4, dpi = 300)

plot_lmer_rts<- plot_model(model1_rt_noint, type = "eff", terms = c("task")) +
  theme_apa()+
  labs(x ="Cue Condition",y="Predicted Reaction Time (ms)", title= "C)")+
  ylim(c(500,2000))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_rts
ggsave('model_RT_100Rtask.jpg', plot_lmer_rts, width = 4, height = 4 , dpi = 300)

#check the plot predicted values
ggeffect(model1_rt_noint, terms = c("task"), type = 'fe')
"task                     | Predicted |           95% CI
-------------------------------------------------------
Shape                    |   1478.24 | 1358.91, 1597.57
Shape + Visual Motion    |   1523.89 | 1404.80, 1642.98
Shape + Tactile Motion   |   1479.97 | 1360.92, 1599.01
Shape + Motion + Tactile |   1441.87 | 1322.88, 1560.85"


####78_B####
data_lmer_RT <- RTtest_filtered_dataset_78_B 
data_lmer_RT$ID <- factor(data_lmer_RT$ID)
data_lmer_RT$exemplar <- as.factor(data_lmer_RT$exemplar)
levels(data_lmer_RT$exemplar)
data_lmer_RT$exemplar <- factor(data_lmer_RT$exemplar, levels = c("Not learned", "Learned"))
data_lmer_RT$task <- as.factor(data_lmer_RT$task)
levels(data_lmer_RT$task) <- c("Shape", "Shape + Tactile Motion","Shape + Visual Motion", "Shape + Motion + Tactile")
data_lmer_RT$task <- factor(data_lmer_RT$task, levels = c("Shape", "Shape + Visual Motion","Shape + Tactile Motion", "Shape + Motion + Tactile"))

model1_rt<-lmer(RTms ~ task*exemplar + 
                  task + exemplar+
                  (1|ID), 
                data = data_lmer_RT)
summary(model1_rt)
model1_rt_noint <-lmer(RTms ~ task + exemplar+
                         (1|ID), 
                       data = data_lmer_RT)
summary(model1_rt_noint)
anova(model1_rt,model1_rt_noint)
"                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_rt_noint    7 109685 109733 -54836    109671                     
model1_rt         10 109686 109755 -54833    109666 4.9527  3     0.1753"
#main effects
model1_noint2 <-lmer(RTms ~ task +
                       (1|ID), 
                     data = data_lmer_RT)
summary(model1_noint2)
anova(model1_rt_noint, model1_noint2)
"EXEMPLAR MAIN EFFECT - NO SIGNIFICANT
                 npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_noint2      6 109684 109725 -54836    109672                     
model1_rt_noint    7 109685 109733 -54836    109671 0.5011  1      0.479"
"CONDITON MAIN EFFECT
                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model1_noint2      4 111423 111450 -55707    111415                         
model1_rt_noint    7 109685 109733 -54836    109671 1743.2  3  < 2.2e-16 ***"
#posthoc values
post_learn = emmeans(model1_noint2, pairwise ~ task, type = 'response', 
                     adjust = 'bonferroni', 
                     lmerTest.limit = 9609, pbkrtest.limit = 9609)
results_learn <- post_learn$contrasts %>% rbind()
results_learn
"TASK
contrast                                              estimate   SE   df t.ratio p.value
 Shape - (Shape + Visual Motion)                           -125 19.7 6997  -6.328  <.0001
 Shape - (Shape + Tactile Motion)                          -740 19.9 6997 -37.280  <.0001
 Shape - (Shape + Motion + Tactile)                        -598 19.8 6997 -30.239  <.0001
 (Shape + Visual Motion) - (Shape + Tactile Motion)        -616 19.6 6997 -31.409  <.0001
 (Shape + Visual Motion) - (Shape + Motion + Tactile)      -473 19.5 6997 -24.251  <.0001
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)      143 19.7 6997   7.262  <.0001"
results_CI_learn <-
  confint(results_learn)
results_CI_learn
#CI
"contrast                                              estimate   SE   df lower.CL upper.CL
 Shape - (Shape + Visual Motion)                           -125 19.7 6997   -176.8    -72.7
 Shape - (Shape + Tactile Motion)                          -740 19.9 6997   -792.9   -688.0
 Shape - (Shape + Motion + Tactile)                        -598 19.8 6997   -649.9   -545.6
 (Shape + Visual Motion) - (Shape + Tactile Motion)        -616 19.6 6997   -667.4   -563.9
 (Shape + Visual Motion) - (Shape + Motion + Tactile)      -473 19.5 6997   -524.4   -421.5
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)      143 19.7 6997     90.9    194.6"

model1_RTS<- plot_model(model1_noint2)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_RTS
ggsave("rts_model_oddratio_78B.png", model1_RTS, width = 5, height = 4, dpi = 300)

plot_lmer_rts<- plot_model(model1_noint2, type = "eff", terms = c("task")) +
  theme_apa()+
  labs(x ="Cue Condition",y="Predicted Reaction Time (ms)", title= "C)")+
  ylim(c(500,2000))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_rts
ggsave('model_RT_78Btask.jpg', plot_lmer_rts, width = 4, height = 4 , dpi = 300)

#check the plot predicted values
ggeffect(model1_noint2, terms = c("task"), type = 'fe')
"task                     | Predicted |           95% CI
-------------------------------------------------------
Shape                    |   1099.25 |  986.85, 1211.65
Shape + Visual Motion    |   1224.01 | 1111.79, 1336.23
Shape + Tactile Motion   |   1839.69 | 1727.36, 1952.01
Shape + Motion + Tactile |   1696.97 | 1584.71, 1809.23"

####78_R####
data_lmer_RT <- test_filtered_dataset_78_R
data_lmer_RT$ID <- factor(data_lmer_RT$ID)
data_lmer_RT$exemplar <- as.factor(data_lmer_RT$exemplar)
levels(data_lmer_RT$exemplar)
data_lmer_RT$exemplar <- factor(data_lmer_RT$exemplar, levels = c("Not learned", "Learned"))
data_lmer_RT$task <- as.factor(data_lmer_RT$task)
levels(data_lmer_RT$task) <- c("Shape", "Shape + Tactile Motion","Shape + Visual Motion", "Shape + Motion + Tactile")
data_lmer_RT$task <- factor(data_lmer_RT$task, levels = c("Shape", "Shape + Visual Motion","Shape + Tactile Motion", "Shape + Motion + Tactile"))

model1_rt<-lmer(RTms ~ task*exemplar + 
                  task + exemplar+
                  (1|ID), 
                data = data_lmer_RT)
summary(model1_rt)
model1_rt_noint <-lmer(RTms ~ task + exemplar+
                         (1|ID), 
                       data = data_lmer_RT)
summary(model1_rt_noint)
anova(model1_rt,model1_rt_noint)
"               npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_rt_noint    7 108438 108486 -54212    108424                     
model1_rt         10 108444 108512 -54212    108424 0.7895  3      0.852"
#main effects
model1_noint2 <-lmer(RTms ~ task +
                       (1|ID), 
                     data = data_lmer_RT)
summary(model1_noint2)
anova(model1_rt_noint, model1_noint2)
"EXEMPLAR MAIN EFFECT - NO SIGNIFICANT
                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_noint2      6 108437 108478 -54212    108425                     
model1_rt_noint    7 108438 108486 -54212    108424 0.2589  1     0.6109"
"CONDITON MAIN EFFECT
                npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model1_noint2      4 108457 108485 -54225    108449                         
model1_rt_noint    7 108438 108486 -54212    108424 24.896  3  1.623e-05 ***"
#posthoc values
post_learn = emmeans(model1_noint2, pairwise ~ task, type = 'response', 
                     adjust = 'bonferroni', 
                     lmerTest.limit = 9609, pbkrtest.limit = 9609)
results_learn <- post_learn$contrasts %>% rbind()
results_learn
"TASK
contrast                                              estimate   SE   df t.ratio p.value
 Shape - (Shape + Visual Motion)                          -25.3 21.7 6849  -1.168  1.0000
 Shape - (Shape + Tactile Motion)                         -38.4 21.6 6851  -1.773  0.4577
 Shape - (Shape + Motion + Tactile)                        59.3 21.5 6851   2.751  0.0358
 (Shape + Visual Motion) - (Shape + Tactile Motion)       -13.0 21.5 6851  -0.606  1.0000
 (Shape + Visual Motion) - (Shape + Motion + Tactile)      84.6 21.4 6851   3.947  0.0005
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)     97.6 21.2 6849   4.600  <.0001"
results_CI_learn <-
  confint(results_learn)
results_CI_learn
#CI
"contrast                                              estimate   SE   df lower.CL upper.CL
 Shape - (Shape + Visual Motion)                          -25.3 21.7 6849   -82.53     31.9
 Shape - (Shape + Tactile Motion)                         -38.4 21.6 6851   -95.44     18.7
 Shape - (Shape + Motion + Tactile)                        59.3 21.5 6851     2.41    116.1
 (Shape + Visual Motion) - (Shape + Tactile Motion)       -13.0 21.5 6851   -69.83     43.8
 (Shape + Visual Motion) - (Shape + Motion + Tactile)      84.6 21.4 6851    28.02    141.1
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)     97.6 21.2 6849    41.61    153.6"

model1_RTS<- plot_model(model1_noint2)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_RTS
ggsave("rts_model_oddratio_78R.png", model1_RTS, width = 5, height = 4, dpi = 300)

plot_lmer_rts<- plot_model(model1_noint2, type = "eff", terms = c("task")) +
  theme_apa()+
  labs(x ="Cue Condition",y="Predicted Reaction Time (ms)", title= "C)")+
  ylim(c(500,2000))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_rts
ggsave('model_RT_78Rtask.jpg', plot_lmer_rts, width = 4, height = 4 , dpi = 300)

#check the plot predicted values
ggeffect(model1_noint2, terms = c("task"), type = 'fe')
"task                     | Predicted |           95% CI
-------------------------------------------------------
Shape                    |   1753.48 | 1594.95, 1912.00
Shape + Visual Motion    |   1778.80 | 1620.33, 1937.27
Shape + Tactile Motion   |   1791.83 | 1633.47, 1950.20
Shape + Motion + Tactile |   1694.22 | 1535.91, 1852.54"

####100B_LS####
data_lmer_RT <- RTtest_data_filtered_100_B_LS
data_lmer_RT$ID <- factor(data_lmer_RT$ID)
data_lmer_RT$exemplar <- as.factor(data_lmer_RT$exemplar)
levels(data_lmer_RT$exemplar)
data_lmer_RT$exemplar <- factor(data_lmer_RT$exemplar, levels = c("Not learned", "Learned"))
data_lmer_RT$task <- as.factor(data_lmer_RT$task)
levels(data_lmer_RT$task) <- c("Shape", "Shape + Tactile Motion","Shape + Visual Motion", "Shape + Motion + Tactile")
data_lmer_RT$task <- factor(data_lmer_RT$task, levels = c("Shape", "Shape + Visual Motion","Shape + Tactile Motion", "Shape + Motion + Tactile"))

model1_rt<-lmer(RTms ~ task*exemplar + 
                  task + exemplar+
                  (1|ID), 
                data = data_lmer_RT)
summary(model1_rt)
model1_rt_noint <-lmer(RTms ~ task + exemplar+
                         (1|ID), 
                       data = data_lmer_RT)
summary(model1_rt_noint)
anova(model1_rt,model1_rt_noint)
"                npar   AIC   BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
model1_rt_noint    7 99445 99492 -49715     99431                     
model1_rt         10 99448 99516 -49714     99428 2.6817  3     0.4433"
#main effects
model1_noint2 <-lmer(RTms ~ exemplar +
                       (1|ID), 
                     data = data_lmer_RT)
summary(model1_noint2)
anova(model1_rt_noint, model1_noint2)
"EXEMPLAR MAIN EFFECT -  SIGNIFICANT
                npar   AIC   BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model1_noint2      6 99467 99508 -49727     99455                         
model1_rt_noint    7 99445 99492 -49715     99431 24.186  1  8.746e-07 ***"
"CONDITON MAIN EFFECT
                npar   AIC   BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model1_noint2      4 99944 99971 -49968     99936                         
model1_rt_noint    7 99445 99492 -49715     99431 505.57  3  < 2.2e-16 ***"
#posthoc values
post_learn = emmeans(model1_rt_noint, pairwise ~ exemplar, type = 'response', 
                     adjust = 'bonferroni', 
                     lmerTest.limit = 9609, pbkrtest.limit = 9609)
results_learn <- post_learn$contrasts %>% rbind()
results_learn
"TASK
contrast                                              estimate   SE   df t.ratio p.value
 Shape - (Shape + Visual Motion)                         -121.6 13.1 6703  -9.301  <.0001
 Shape - (Shape + Tactile Motion)                        -229.8 13.3 6703 -17.334  <.0001
 Shape - (Shape + Motion + Tactile)                      -276.9 13.2 6703 -21.015  <.0001
 (Shape + Visual Motion) - (Shape + Tactile Motion)      -108.3 13.3 6704  -8.165  <.0001
 (Shape + Visual Motion) - (Shape + Motion + Tactile)    -155.4 13.2 6703 -11.801  <.0001
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)    -47.1 13.4 6704  -3.527  0.0025
EXEMPLAR
 contrast              estimate   SE   df t.ratio p.value
 Not learned - Learned       48 9.76 6703   4.921  <.0001"
results_CI_learn <-
  confint(results_learn)
results_CI_learn
#CI
" contrast                                              estimate   SE   df lower.CL upper.CL
 Shape - (Shape + Visual Motion)                         -121.6 13.1 6703   -156.0    -87.1
 Shape - (Shape + Tactile Motion)                        -229.8 13.3 6703   -264.8   -194.8
 Shape - (Shape + Motion + Tactile)                      -276.9 13.2 6703   -311.7   -242.2
 (Shape + Visual Motion) - (Shape + Tactile Motion)      -108.3 13.3 6704   -143.3    -73.3
 (Shape + Visual Motion) - (Shape + Motion + Tactile)    -155.4 13.2 6703   -190.1   -120.6
 (Shape + Tactile Motion) - (Shape + Motion + Tactile)    -47.1 13.4 6704    -82.4    -11.9
 
 EXEMPLAR
  contrast              estimate   SE   df lower.CL upper.CL
 Not learned - Learned       48 9.76 6703     28.9     67.1"

model1_RTS<- plot_model(model1_rt_noint)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_RTS
ggsave("rts_model_oddratio_100B_LS.png", model1_RTS, width = 5, height = 4, dpi = 300)

plot_lmer_rts<- plot_model(model1_rt_noint, type = "eff", terms = c("exemplar")) +
  theme_apa()+
  labs(x ="Exemplar",y="Predicted Reaction Time (ms)", title= "C)")+
  ylim(c(500,2000))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_rts
ggsave('model_RT_100B_LStask.jpg', plot_lmer_rts, width = 4, height = 4 , dpi = 300)
ggsave('model_RT_100B_LSexp.jpg', plot_lmer_rts, width = 4, height = 4 , dpi = 300)

#check the plot predicted values
ggeffect(model1_rt_noint, terms = c("exemplar"), type = 'fe')
"task                     | Predicted |           95% CI
-------------------------------------------------------
Shape                    |    910.21 |  828.88,  991.53
Shape + Visual Motion    |   1031.76 |  950.44, 1113.08
Shape + Tactile Motion   |   1140.02 | 1058.57, 1221.46
Shape + Motion + Tactile |   1187.15 | 1105.77, 1268.54"
"exemplar    | Predicted |           95% CI
------------------------------------------
Not learned |   1096.42 | 1015.66, 1177.18
Learned     |   1048.41 |  968.31, 1128.50"
