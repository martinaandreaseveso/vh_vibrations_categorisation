###for general functions####
library(broom)
library(car)
library(caret)
library(plyr)
library(psych)
library(tidyverse)
library(dplyr)
library(reshape2)
library(qwraps2) 
library(devtools)
library(tidytext)
library(rstatix)
library(fmsb)
library(rcompanion)
library(Rmisc)
#for sample matching 
library(MatchIt)
library(optmatch)
#for plotting
library(cowplot)
library(dotwhisker)
library(GGally)
library(ggeffects)
library(gridExtra)
library(ggpubr)
library(jtools)
library(sjPlot)
library(effects)
library(latticeExtra)
library(corrplot)
library(RColorBrewer)
library(jcolors)
library(plotly)
library(gplots)
library(ggthemes)
library(ggstance)
library(dplyr)
library(stats)
#remotes::install_github("ricardo-bion/ggradar")
library(ggradar)
library(networkD3)
library(wesanderson)
#for K means clustering and analyses 
library(kml)
library(kml3d)
library(ez)
library(lme4)
library(emmeans)
library(DHARMa)
library(performance)
library(broom.mixed)
library(jtools)
#for model convergence issues 
library(optimx)
library(parallel)
library(minqa) 
#for MDS
library(magrittr)
library(dplyr)
library(ggpubr)
library(MASS)
library(factoextra)
library(NbClust)

####Data cleaning####
getwd()
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\data")

#load in datafiles to global environment from working directory - 
#make sure these files are in the same directory then import csv
temp = list.files(pattern="*.csv")
for (i in 1:length(temp)) assign(temp[i], read.csv(temp[i]))
objs <- mget(ls(envir = globalenv()))
dfs <- objs[map_lgl(objs, is.data.frame)]
#merge the different datafiles 
vibration_data <- reduce(dfs, full_join)
vibration_data$participant <- as.factor(vibration_data$participant)
table(vibration_data$participant)

#Demographics
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\plots")
names(vibration_data)
#create a list of columns we want called 'cols'
cols <- c('participant', "sex_slider.response","education_slider.response", 'vision_slider.response', 'audition_slider.response')
#match the names in cols to the column names in the datafile and extract them
demog <- vibration_data[cols]
#remove duplicate columns and NA columns 
m_demo1 <- demog[!duplicated(demog), ]
demogfinal <- m_demo1[complete.cases(m_demo1),]
levels(demogfinal$participant)  
demog11 <- demogfinal

colnames(demog11)[1] <- 'ID'
colnames(demog11)[2] <- 'sex'
colnames(demog11)[3] <- 'completed_edu'
colnames(demog11)[4] <- 'problem_vision'
colnames(demog11)[5] <- 'problem_hearing'

demog11$sex <- as.factor(demog11$sex)
demog11$completed_edu <- as.factor(demog11$completed_edu)
demog11$problem_vision <- as.factor(demog11$problem_vision)
demog11$problem_hearing <- as.factor(demog11$problem_hearing)

write.table(demog11, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\df\\demographics.csv",  sep= ",")

#logic
demographics$sex <- as.factor(demographics$sex)
demographics$completed_edu <- as.factor(demographics$completed_edu)
demographics$problem_vision <- as.factor(demographics$problem_vision)
demographics$problem_hearing <- as.factor(demographics$problem_hearing)

levels(demographics$sex)# <- c('Male', 'Female')
levels(demographics$problem_vision) #<-  c('Yes')
levels(demographics$problem_hearing)# <-  c('Yes')
levels(demographics$completed_edu)# <-  c('Primary School','Secondary School', 'Third level or higher')

demographic_summary <-demog %>%
  group_by(ID, sex) %>%
  summarise(age=mean(age))

summary(demog$sex)
summary(demog$normal_vision)
summary(demog$normal_hearing)
summary(demog$completed_edu)

#Perceptual matching 
names(vibration_data)
cols_disc1<- c("participant","synch","vibration_pm", "test_resp.response", "test_resp.rt")
pm_data <- vibration_data[cols_disc1]
pm_data <- pm_data[!duplicated(pm_data), ]
pm_finaldata <- pm_data[complete.cases(pm_data),]
pm_finaldata$participant <- as.factor(pm_finaldata$participant)
levels(pm_finaldata$participant)  
pm_finaldata$task <- "Perceptual_matching"
colnames(pm_finaldata)[1] <- 'ID'
colnames(pm_finaldata)[2] <- 'asynchr'
colnames(pm_finaldata)[3] <- 'vibration'
colnames(pm_finaldata)[4] <- 'percevied_sync'
colnames(pm_finaldata)[5] <- 'RTms'
pm_finaldata$RTms <- pm_finaldata$RTms*1000

pm_finaldata$asynchr <- as.factor(pm_finaldata$asynchr)
levels(pm_finaldata$asynchr) <- c("150ms_offset", "300ms_offset", "no_offset")
pm_finaldata$asynchr <- factor(pm_finaldata$asynchr, levels=c("no_offset","150ms_offset", "300ms_offset"))
pm_finaldata$vibration<- as.factor(pm_finaldata$vibration)
levels(pm_finaldata$vibration) <- c( "360rotation", "360rotation", "360rotation", "jump" , "jump"  , "jump", 
                                     "swing","swing","swing","vibration", "vibration",   "vibration" )
levels(pm_finaldata$vibration) <- c("Rotation","Jump" , "Swing", "Vibration")
levels(pm_finaldata$asynchr) <- c("No offset","150ms offset" ,"300ms offset")

plotpm <-  ggplot(data = pm_finaldata, aes(x = vibration, y = percevied_sync, col = asynchr , group = asynchr)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) + 
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  #facet_wrap(~ID) +
  labs(title = "Perceptual Matching Task Performance", x = "Vibration type", y = "Perceived Synchrony") +
  scale_color_manual(values = c( "green","orange","red")) +
  theme_apa()+
  theme(legend.title = element_text("Group"), legend.position = "top")+
  coord_cartesian(ylim = c(1,5))
plotpm
ggsave('perceptual_matching.jpg', plotpm, width = 8, height = 6, dpi = 300)
write.table(pm_finaldata, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\df\\perceptualmatching_data.csv",  sep= ",")

#anova to check for perceptual matching performance
#descriptive statistics
pm_finaldata$asynchr <- as.factor(pm_finaldata$asynchr)
pm_finaldata$percevied_sync
summary_stats <- pm_finaldata %>%
  group_by(asynchr) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

# Check for normality of residuals
# Fit a linear model
model <- lm(percevied_sync ~ asynchr, data = pm_finaldata)
# Shapiro-Wilk test for normality of residuals - violated
shapiro_test <- shapiro.test(residuals(model))
print(shapiro_test)
"	Shapiro-Wilk normality test

data:  residuals(model)
W = 0.90973, p-value < 2.2e-16"
# check for homogeneity of variances - violated
levene_test <- leveneTest(percevied_sync ~ asynchr, data = pm_finaldata)
print(levene_test)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value Pr(>F)  
group   2  3.8468  0.022 *
      483        "
summary_stats <- pm_finaldata %>%
  group_by(ID,asynchr) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

welch_result <- oneway.test(mean ~ asynchr, data = summary_stats, var.equal = FALSE)
print(welch_result)
"	One-way analysis of means (not assuming equal variances)

data:  mean and asynchr
F = 6.1174, num df = 2.000, denom df = 86.866, p-value = 0.003269"
#post hoc
install.packages("PMCMRplus")
library(PMCMRplus)
games_howell <- gamesHowellTest(mean ~ asynchr, data = summary_stats)
print(games_howell)
"Pairwise comparisons using Games-Howell test - data: mean by asynchr
             No offset 150ms offset
150ms offset 0.0163    -           
300ms offset 0.0052    0.6974      

No offset vs. 150ms offset: p=0.0163 
No offset vs. 300ms offset: p= 0.0052
150ms offset vs. 300ms offset: p=0.6974"

#structure of summary_stats:
summary_stats <- pm_finaldata %>%
   group_by(asynchr) %>%
   summarise(
     mean = mean(percevied_sync, na.rm = TRUE),
     sd = sd(percevied_sync, na.rm = TRUE),
     n = n(),
     se = sd / sqrt(n),  # Standard Error
    ci = qt(0.975, df = n - 1) * se  # 95% Confidence Interval
    )
perceived_synch <- ggplot(summary_stats, aes(x = asynchr, y = mean, fill = asynchr)) +
  geom_point(alpha = 0.8) +  # If you want bars
  geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = 0.2, color = "black") +  # Add 95% CI
  stat_summary(geom = "point", size = 4, shape = 21) +  # Add summary points
  theme_apa()+
  labs(
    title = "Perceived Synchrony across Asynchrony Levels",
    x = "Asynchrony Levels",
    y = "Perceived Synchrony"
  ) +
  ylim(2,5)+
  annotate("text", x = 1.5, y = max(summary_stats$mean) + 0.5, label = "**", size = 5, color = "black") +  # No offset vs. 150ms offset
  annotate("text", x = 2, y = max(summary_stats$mean) + 1, label = "***", size = 5, color = "black") +    # No offset vs. 300ms offset
  annotate("text", x = 2.5, y = max(summary_stats$mean) + 0.2, label = "ns", size = 4, color = "black")   # 150ms offset vs. 300ms offset
ggsave('perceived_synch.jpg', perceived_synch, width = 6, height = 6, dpi = 300)


###Learning###
names(vibration_data)
cols_disc2<- c("participant", "category", "exemplar", "stim",  "vibration1","prop_learning", "learning_resp.response", "corrAns","learning_resp.rt", "learning_trials.thisN")
learning_data <- vibration_data[cols_disc2]
learning_data <- learning_data[!duplicated(learning_data), ]
learning_finaldata <- learning_data[complete.cases(learning_data),]
learning_finaldata$participant <- as.factor(learning_finaldata$participant)
levels(learning_finaldata$participant)  
learning_finaldata$task <- "Learning"
colnames(learning_finaldata)[1] <- 'ID'
colnames(learning_finaldata)[5] <- 'vibration_type'
colnames(learning_finaldata)[7] <- 'response'
colnames(learning_finaldata)[8] <- 'correct_response'
colnames(learning_finaldata)[9] <- 'RTms'
colnames(learning_finaldata)[10] <- 'trial_n'
learning_finaldata$RTms <- learning_finaldata$RTms*1000
learning_finaldata$accuracy <-  ifelse(learning_finaldata$correct_response == learning_finaldata$response, 1,0)
learning_finaldata$trial_n <- learning_finaldata$trial_n +1 
#clean dataset
cols_learning_finaldata.b<- c("ID", "task", "category", "exemplar", "stim",'vibration_type',"trial_n","prop_learning", "accuracy","RTms") 
learning_finaldata<- learning_finaldata[cols_learning_finaldata.b]
learning_finaldata$category<- as.factor(learning_finaldata$category)
learning_finaldata$exemplar<- as.factor(learning_finaldata$exemplar)
learning_finaldata$stim<- as.factor(learning_finaldata$stim)
learning_finaldata$vibration_type<- as.factor(learning_finaldata$vibration_type)
learning_finaldata$trial_n<- as.factor(learning_finaldata$trial_n)

#exclusion criteria = below-chance accuracy in 2+ vibration types#
learning_finaldata_excl <- learning_finaldata %>%
  group_by(ID,vibration_type) %>%
  summarise(mean_acc=mean(accuracy),
            mean_rt=mean(RTms))

# Summarize data and identify participants with 
below_chance_ids <- learning_finaldata_excl %>%
  filter(mean_acc <= 0.50) %>%              # Filter for accuracy below 0.50
  group_by(ID) %>%                          # Group by participant ID
  summarise(below_chance_count = n()) %>%   # Count instances of below-chance accuracy
  filter(below_chance_count >= 2)           # Keep only those with 2+ below-chance conditions
# Display IDs with below-chance performance in 2+ vibration types
below_chance_ids
#PARTICIPANT TO BE EXCLUDED WITH BELOW  AT CHANCE
exclude_ids <- c( "6630d342e33ca32f75561f05")
# Exclude these IDs from the original dataset
learning_finaldata_excl_filtered <- learning_finaldata %>%
  filter(!ID %in% exclude_ids)
# View the filtered dataset
learning_finaldata_excl_filtered <-learning_finaldata
table(learning_finaldata_excl_filtered$ID)
levels(learning_finaldata_excl_filtered$vibration_type) <- c("Rotation","Jump" , "Swing", "Vibration")
levels(learning_finaldata_excl_filtered$category) <- c("Category A", "Category B")
learning_finaldata_excl_filtered$accuracy <- learning_finaldata_excl_filtered$accuracy*100
learning_finaldata_excl_filtered$exp <- "100_block"
write.table(learning_finaldata_excl_filtered, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\df\\learning_data_filtered.csv",  sep= ",")

plot_learning<-  ggplot(data = learning_finaldata_excl_filtered, aes(x = vibration_type, y = accuracy, col = category, group = category)) +
 stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  geom_hline(yintercept = 75, linetype = "dashed", color = "black") +
  geom_hline(yintercept = 50, linetype = "dashed", color = "black") +
  #geom_hline(yintercept = 0.25, linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  #facet_wrap(~ID) +
  labs(title = "Percentage Accuracy during Categorisation Learning", x = "Vibration type", y = "Accuracy (%)", fill= "Task") +
  scale_color_manual(values = c( "#EBA07EFF","#A8554EFF")) +
  theme_apa()+
  theme(legend.title = element_text("Task"), legend.position = "top")+
  coord_cartesian(ylim = c(25,100))
plot_learning

ggsave('plot_learning.jpg', plot_learning, width = 6, height = 6, dpi = 300)
ggsave('plot_learning_individual.jpg', plot_learning, width = 10, height = 10, dpi = 300)

plot_l_cat_stim<-  ggplot(data = learning_finaldata_excl_filtered, aes(x = stim, y = accuracy, col = category, group = category)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  stat_summary(geom = 'line', alpha = 0.9, linewidth = 1) +
  geom_hline(yintercept = 75, linetype = "dashed", color = "black") +
  geom_hline(yintercept = 50, linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  #facet_wrap(~ID) +
  labs(title = "Percentage Accuracy during Categorisation Learning", x = "Stimulus", y = "Accuracy (%)", fill= "Task") +
  scale_color_manual(values = c( "#EBA07EFF","#A8554EFF")) +
  theme_apa()+
  theme(legend.title = element_text("Task"), legend.position = "top")+
  coord_cartesian(ylim = c(25,100))
plot_l_cat_stim
ggsave('plot_learningcat_stim.jpg', plot_l_cat_stim, width = 6, height = 8, dpi = 300)

#Final dataset
learning_finaldata_excl_filtered <- merge(demographics, learning_finaldata_excl_filtered,  by = c('ID'))
write.table(learning_finaldata_excl_filtered, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\df\\learning_data.csv",  sep= ",")

###TEST####
#test - shape_static
names(vibration_data)
cols_testshape<- c("participant", "category_test", "exemplar_test", "stim_test","vibration1_test", "test_resp_s.response", "test_resp_s.rt", "s_loop.thisN")
shape_data <- vibration_data[cols_testshape]
shape_data <- shape_data[!duplicated(shape_data), ]
shape_data <- shape_data[complete.cases(shape_data),]
shape_data$participant <- as.factor(shape_data$participant)
levels(shape_data$participant)  
shape_data$task <- "shape_only"
colnames(shape_data)[1] <- 'ID'
colnames(shape_data)[2] <- 'category'
colnames(shape_data)[3] <- 'exemplar'
colnames(shape_data)[4] <- 'stim'
colnames(shape_data)[5] <- 'vibration_type'
colnames(shape_data)[6] <- 'response'
colnames(shape_data)[7] <- 'RTms'
colnames(shape_data)[8] <- 'trial_n'
shape_data$RTms <- shape_data$RTms*1000
shape_data$corrAns <-  ifelse(shape_data$category == "category_A", "A","B")
shape_data$accuracy <-  ifelse(shape_data$corrAns == shape_data$response, 1,0)
shape_data$vibration_type <- as.factor(shape_data$vibration_type)
levels(shape_data$vibration_type)<- c("None","None","None","None")
levels(shape_data$vibration_type)
shape_data$trial_n <- shape_data$trial_n +1 
#clean dataset
cols_shape_data.b<- c("ID", "task", "category", "exemplar", "stim",'vibration_type', "trial_n", "accuracy","RTms") 
shape_data<- shape_data[cols_shape_data.b]
shape_data$category<- as.factor(shape_data$category)
shape_data$exemplar<- as.factor(shape_data$exemplar)
shape_data$stim<- as.factor(shape_data$stim)
shape_data$vibration_type<- as.factor(shape_data$vibration_type)

#test - motion
names(vibration_data)
cols_testshape_motion<- c("participant", "category_test", "exemplar_test", "stim_test","vibration1_test", "test_resp_sm.response", "test_resp_sm.rt","sm_loop.thisN")
motion_data <- vibration_data[cols_testshape_motion]
motion_data <- motion_data[!duplicated(motion_data), ]
motion_data <- motion_data[complete.cases(motion_data),]
motion_data$participant <- as.factor(motion_data$participant)
levels(motion_data$participant)  
motion_data$task <- "shape_motion"
colnames(motion_data)[1] <- 'ID'
colnames(motion_data)[2] <- 'category'
colnames(motion_data)[3] <- 'exemplar'
colnames(motion_data)[4] <- 'stim'
colnames(motion_data)[5] <- 'vibration_type'
colnames(motion_data)[6] <- 'response'
colnames(motion_data)[7] <- 'RTms'
colnames(motion_data)[8] <- 'trial_n'
motion_data$RTms <- motion_data$RTms*1000
motion_data$corrAns <-  ifelse(motion_data$category == "category_A", "A","B")
motion_data$accuracy <-  ifelse(motion_data$corrAns == motion_data$response, 1,0)
motion_data$trial_n <- motion_data$trial_n +1 
#clean dataset
cols_motion_data.b<- c("ID", "task", "category", "exemplar", "stim",'vibration_type', "trial_n","accuracy","RTms") 
motion_data<- motion_data[cols_motion_data.b]
motion_data$category<- as.factor(motion_data$category)
motion_data$exemplar<- as.factor(motion_data$exemplar)
motion_data$stim<- as.factor(motion_data$stim)
motion_data$vibration_type<- as.factor(motion_data$vibration_type)

#test - shape_static + haptic
names(vibration_data)
cols_disc2<- c("participant", "category_test", "exemplar_test", "stim_test","vibration1_test", "test_resp_sh.response", "test_resp_sh.rt", "sh_loops.thisN")
shape_vibration_data <- vibration_data[cols_disc2]
shape_vibration_data <- shape_vibration_data[!duplicated(shape_vibration_data), ]
shape_vibration_data <- shape_vibration_data[complete.cases(shape_vibration_data),]
shape_vibration_data$participant <- as.factor(shape_vibration_data$participant)
levels(shape_vibration_data$participant)  
shape_vibration_data$task <- "shape_haptic"
colnames(shape_vibration_data)[1] <- 'ID'
colnames(shape_vibration_data)[2] <- 'category'
colnames(shape_vibration_data)[3] <- 'exemplar'
colnames(shape_vibration_data)[4] <- 'stim'
colnames(shape_vibration_data)[5] <- 'vibration_type'
colnames(shape_vibration_data)[6] <- 'response'
colnames(shape_vibration_data)[7] <- 'RTms'
colnames(shape_vibration_data)[8] <- 'trial_n'
shape_vibration_data$RTms <- shape_vibration_data$RTms*1000
shape_vibration_data$corrAns <-  ifelse(shape_vibration_data$category == "category_A", "A","B")
shape_vibration_data$accuracy <-  ifelse(shape_vibration_data$corrAns == shape_vibration_data$response, 1,0)
shape_vibration_data$trial_n <- shape_vibration_data$trial_n +1 
#clean dataset
cols_shape_vibration_data.b<- c("ID", "task", "category", "exemplar", "stim",'vibration_type', "trial_n","accuracy","RTms") 
shape_vibration_data<- shape_vibration_data[cols_shape_vibration_data.b]
shape_vibration_data$category<- as.factor(shape_vibration_data$category)
shape_vibration_data$exemplar<- as.factor(shape_vibration_data$exemplar)
shape_vibration_data$stim<- as.factor(shape_vibration_data$stim)
shape_vibration_data$vibration_type<- as.factor(shape_vibration_data$vibration_type)

#test - motion + haptic
names(vibration_data)
cols_testshape<- c("participant", "category_test", "exemplar_test", "stim_test","vibration1_test", "test_resp_smh.response", "test_resp_smh.rt","smh_loop.thisN")
motion_vibration_data <- vibration_data[cols_testshape]
motion_vibration_data <- motion_vibration_data[!duplicated(motion_vibration_data), ]
motion_vibration_data <- motion_vibration_data[complete.cases(motion_vibration_data),]
motion_vibration_data$participant <- as.factor(motion_vibration_data$participant)
levels(motion_vibration_data$participant)  
motion_vibration_data$task <- "motion_vibration"
colnames(motion_vibration_data)[1] <- 'ID'
colnames(motion_vibration_data)[2] <- 'category'
colnames(motion_vibration_data)[3] <- 'exemplar'
colnames(motion_vibration_data)[4] <- 'stim'
colnames(motion_vibration_data)[5] <- 'vibration_type'
colnames(motion_vibration_data)[6] <- 'response'
colnames(motion_vibration_data)[7] <- 'RTms'
colnames(motion_vibration_data)[8] <- 'trial_n'
motion_vibration_data$RTms <- motion_vibration_data$RTms*1000
motion_vibration_data$corrAns <-  ifelse(motion_vibration_data$category == "category_A", "A","B")
motion_vibration_data$accuracy <-  ifelse(motion_vibration_data$corrAns == motion_vibration_data$response, 1,0)
motion_vibration_data$trial_n <- motion_vibration_data$trial_n +1 
#clean dataset
cols_motion_vibration_data.b<- c("ID", "task", "category", "exemplar", "stim",'vibration_type',"trial_n", "accuracy","RTms") 
motion_vibration_data<- motion_vibration_data[cols_motion_vibration_data.b]
motion_vibration_data$category<- as.factor(motion_vibration_data$category)
motion_vibration_data$exemplar<- as.factor(motion_vibration_data$exemplar)
motion_vibration_data$stim<- as.factor(motion_vibration_data$stim)
motion_vibration_data$vibration_type<- as.factor(motion_vibration_data$vibration_type)

test_data <- rbind(shape_data, shape_vibration_data, motion_data, motion_vibration_data)

# Exclude these IDs from the original dataset
test_data_filtered <- test_data %>%
  filter(!ID %in% exclude_ids)

# View the filtered dataset
test_data_filtered <- test_data
test_data_filtered
table(test_data_filtered$ID)
test_data_filtered$task <- as.factor(test_data_filtered$task)
levels(test_data_filtered$task) <- c("Shape Motion Haptic","Shape Haptic", "Shape Motion" ,"Shape")
levels(test_data_filtered$exemplar) <- c("Learned", "Not learned")
test_data_filtered$accuracy <- test_data_filtered$accuracy*100
test_data_filtered$exp <- "100_block"
test_data_filtered <- merge(demographics, test_data_filtered,  by = c('ID'))
write.table(test_data_filtered, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\df\\test_data_filtered.csv",  sep= ",")

plot_test <-  ggplot(data = test_data_filtered, aes(x = task, y = accuracy, col = exemplar, group = exemplar)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  #stat_summary(fun.y = mean,
   #            fun.ymin = function(x) mean(x) - sd(x), 
    #           fun.ymax = function(x) mean(x) + sd(x), 
     #          geom = "pointrange") +
  geom_hline(yintercept = 75, linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  #facet_wrap(~ID) +
  labs(title = "Percentage Accuracy during Test", x = "Cue Condition", y = "Accuracy (%)", fill= "Exemplar") +
  scale_color_manual(values = c( "indianred4","cornflowerblue")) +
  theme_apa()+
  coord_cartesian(ylim = c(0,100))+
  theme(legend.title = element_text("Task"), legend.position = "top")
plot_test

#Remove outliers - exclusion criteria- RTs and cut off 
#a - GROUP cut_off - at least 3 SDs above the mean 
test_data_filtered_RT<- test_data_filtered
upper_cut_off <- mean(test_data_filtered_RT$RTms) + 2.5*(sd(test_data_filtered_RT$RTms))
lower_cut_off <- mean(test_data_filtered_RT$RTms) - 2.5*(sd(test_data_filtered_RT$RTms))
d_groupcutoff<- subset(test_data_filtered_RT, RTms < upper_cut_off & RTms > lower_cut_off)
test_data_filtered_RT$outlier_RT <- ifelse(test_data_filtered_RT$RTms > upper_cut_off |
                             test_data_filtered_RT$RTms < lower_cut_off, 'Yes', 'No')
table(test_data_filtered_RT$outlier_RT)
test_data_filtered_RT_noGroupoutliers <- subset(test_data_filtered_RT, outlier_RT == 'No')
#b - INDIVIDUAL cut-off - 4 SDs above the individual mean
test_data_filtered_RT_Indcutoff <- test_data_filtered_RT_noGroupoutliers %>% group_by(ID) %>%
  filter(RTms < mean(RTms) + (4 * sd(RTms)), RTms > mean(RTms) - (4 * sd(RTms)))
boxplot(test_data_filtered_RT_Indcutoff$RTms)
hist(test_data_filtered_RT_Indcutoff$RTms)
range(test_data_filtered_RT_Indcutoff$RTms)
#c - check people with RT below 500 ms 
d_below500 <- subset(test_data_filtered_RT_noGroupoutliers, RTms < 250) # 50 participant with RT fastest of 150 ms
summary(d_below500)
#final dataset -with no outliers
test_data_noout_RT <- subset(test_data_filtered_RT_noGroupoutliers, RTms > 250)
write.table(test_data_noout_RT, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_100_Block\\df\\RT_test_data_filtered.csv",  sep= ",")

plot_test_RTs <-  ggplot(data = test_data_noout_RT, aes(x = task, y = RTms, col = exemplar, group = exemplar)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  #facet_wrap(~ID) +
  labs(title = "Reaction Times during Test", x = "Cue Condition", y = "Reaction Times (ms)", fill= "Exemplar") +
  scale_color_manual(values = c( "indianred4","cornflowerblue")) +
  theme_apa()+
  coord_cartesian(ylim = c(750,2000))+
  theme(legend.title = element_text("Task"), legend.position = "top")
plot_test_RTs

plot_test_2 <-  ggplot(data = test_data_filtered, aes(x = vibration_type, y = accuracy, col = exemplar, group = exemplar)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  geom_hline(yintercept = 0.8, linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  facet_wrap(~task) +
  labs(title = "Percentage Accuracy during Test", x = "Cue Condition", y = "Accuracy (%)", fill= "Exemplar") +
  scale_color_manual(values = c( "indianred4","cornflowerblue")) +
  theme_apa()+
  theme(legend.title = element_text("Task"), legend.position = "top")
plot_test_2

ggsave('plot_test.jpg', plot_test, width = 9, height = 6, dpi = 300)
ggsave('plot_test_RT.jpg', plot_test_RTs, width = 8, height = 6, dpi = 300)
ggsave('plot_test_motiontype.jpg', plot_test_2, width = 8, height = 6, dpi = 300)
ggsave('plot_test_individual.jpg', plot_test, width = 12, height = 12, dpi = 300)

