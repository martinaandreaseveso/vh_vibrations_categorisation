###for general functions####
library(broom)
library(car)
library(caret)
library(plyr)
library(psych)
library(tidyverse)
library(dplyr)
library(reshape2)
#library(qwraps2) 
#library(devtools)
#library(tidytext)
library(rstatix)
#library(fmsb)
library(rcompanion)
library(Rmisc)
#for plotting
library(cowplot)
library(dotwhisker)
library(GGally)
library(ggeffects)
library(gridExtra)
library(ggpubr)
library(jtools)
library(sjPlot)
library(effects)
#library(latticeExtra)
#library(corrplot)
library(RColorBrewer)
library(jcolors)
#library(plotly)
library(gplots)
library(ggplot2)
library(ggthemes)
library(ggstance)
library(stats)
#for K means clustering and analyses 
library(ez)
library(lme4)
library(emmeans)
library(performance)
library(broom.mixed)
library(jtools)
library(LaplacesDemon)
#for model convergence issues 
#library(optimx)
#library(parallel)
#library(minqa) 

#####
getwd()
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\ANALYSIS_MAY25\\accuracy")
setwd("C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\vibration\\ANALYSIS_MAY25\\accuracy")
# Okabe & Ito color-blind–friendly palette
cbPalette <- c(
  "#E69F00", # orange
  "#56B4E9", # sky blue
  "#009E73", # bluish green
  "#F0E442", # yellow
  "#0072B2", # blue
  "#D55E00", # vermillion
  "#CC79A7"  # reddish purple
)
####100_B####
acc_data <- test_filtered_dataset_100_B 
#prep dataset for models
acc_data$ID <- factor(acc_data$ID)
acc_data$exemplar <- as.factor(acc_data$exemplar)
levels(acc_data$exemplar)
acc_data$exemplar <- factor(acc_data$exemplar, levels = c("Not learned", "Learned"))
acc_data$task <- as.factor(acc_data$task)
levels(acc_data$task) 
#paper
levels(acc_data$task) <- c("Sv", "SvMt","SvMv", "SvMvt")
acc_data$task <- factor(acc_data$task, levels = c("Sv", "SvMv","SvMt", "SvMvt"))

#test accuracy & generalisation
model1 <- glmer(
  accuracy ~ 0 + task + exemplar + task:exemplar +
    (0 + task + exemplar + task:exemplar | ID),
  data = acc_data,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model1)
"boundary (singular) fit: see help('isSingular')"
#the interaction effect in the slope it's making the model not converging (fit isSingular)

#model with no interaction effect in the slope
model2 <- glmer(
  accuracy ~ 1+ task + exemplar + task:exemplar +
    (1+ task + exemplar | ID),
  data = acc_data,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model2)
model2_noint <- glmer(
  accuracy ~ 1 + task + exemplar +
    (1 + task + exemplar | ID),
  data = acc_data,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model2_noint)
anova(model2,model2_noint)
"             npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)  
model2_noint   20 9712.9 9857.0 -4836.5   9672.9                       
model2         23 9712.5 9878.2 -4833.3   9666.5 6.3967  3    0.09383 ."
#interaction doesn't explain the model better, no better fit to the data
#check main effects
model2_noint.b <- glmer(
  accuracy ~ 1 + task +
    (1 + task + exemplar | ID),
  data = acc_data,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model2_noint.b)
anova(model2_noint.b,model2_noint)
#TASK
"               npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model2_noint.b   17 9733.4 9855.8 -4849.7    9699.4                         
model2_noint     20 9712.9 9857.0 -4836.5    9672.9 26.499  3  7.497e-06 ***"
#EXEMPLAR
"               npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model2_noint.b   19 9722.7 9859.5 -4842.3    9684.7                         
model2_noint     20 9712.9 9857.0 -4836.5    9672.9 11.761  1  0.0006048 ***"

"FINAL MODEL - > 2_no int
"
#post-hoc comparisons
library(emmeans)
post_learn = emmeans(model2_noint, pairwise~task, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn
"TASK
 contrast                           odds.ratio     SE  df null z.ratio p.value
 Shape / Shape Motion                    0.395 0.0853 Inf    1  -4.301  0.0001
 Shape / Shape Haptic                    0.565 0.0871 Inf    1  -3.706  0.0013
 Shape / Shape Motion Haptic             0.209 0.0572 Inf    1  -5.719  <.0001
 Shape Motion / Shape Haptic             1.429 0.2680 Inf    1   1.903  0.3426
 Shape Motion / Shape Motion Haptic      0.528 0.0941 Inf    1  -3.584  0.0020
 Shape Haptic / Shape Motion Haptic      0.370 0.0806 Inf    1  -4.562  <.0001

EXEMPLAR
contrast              odds.ratio     SE  df null z.ratio p.value
 Not learned / Learned       0.67 0.0749 Inf    1  -3.581  0.0003"
results_CI_learn <- 
  confint(results_learn)
results_CI_learn
" TASK
contrast                           odds.ratio     SE  df asymp.LCL asymp.UCL
 Shape / Shape Motion                    0.395 0.0853 Inf     0.224     0.698
 Shape / Shape Haptic                    0.565 0.0871 Inf     0.376     0.848
 Shape / Shape Motion Haptic             0.209 0.0572 Inf     0.101     0.430
 Shape Motion / Shape Haptic             1.429 0.2680 Inf     0.871     2.344
 Shape Motion / Shape Motion Haptic      0.528 0.0941 Inf     0.330     0.845
 Shape Haptic / Shape Motion Haptic      0.370 0.0806 Inf     0.208     0.657

EXEMPLAR
 contrast              odds.ratio     SE  df asymp.LCL asymp.UCL
 Not learned / Learned       0.67 0.0749 Inf     0.538     0.834"

#plot of the model
library(jtools)
model1<- plot_model(model2_noint)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1
ggsave("acc_model_oddratio_100B.png", width = 5, height = 4, dpi = 300)

model2_plot<- plot_model(model2_noint, type = "eff", terms = c("task","exemplar"),bias_correction =TRUE)+
  geom_hline(yintercept = 0.5, color = "black", linetype = "dashed", size = 0.5) +
 # scale_color_manual(values = cbPalette[c(3,7)]) + 
  theme_apa()+
  labs(x ="Cue Condition",y="Accuracy (%)", title= "A)")+
  theme(legend.position = "top") +
  coord_cartesian(ylim = c(0.5,1))
model2_plot
ggsave("acc_model_int_100B_2.png", width = 5, height = 5,dpi = 300)
ggsave("acc_model_int_100B_paper.png", width = 5, height = 5,dpi = 300)

#check the plot predicted values
ggeffect(model2_noint, terms = c("exemplar"), type = 'fe')
"task                | Predicted |     95% CI
--------------------------------------------
Shape               |      0.65 | 0.56, 0.72
Shape Motion        |      0.82 | 0.74, 0.88
Shape Haptic        |      0.76 | 0.70, 0.82
Shape Motion Haptic |      0.90 | 0.83, 0.94"

"# Predicted probabilities of accuracy

exemplar    | Predicted |     95% CI
------------------------------------
Not learned |      0.75 | 0.69, 0.81
Learned     |      0.82 | 0.75, 0.88"
#exp(fixef(final_model))

plot_lmer_accuracy_exemplar<- plot_model(model2_noint, type = "eff", terms = c("exemplar")) +
  labs(x ="Exemplar Type",y="Predicted Accuracy (%)", title= "B)")+
  theme_apa()+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  coord_cartesian(ylim = c(0.45,1))
plot_lmer_accuracy_exemplar
plot_lmer_accuracy_cc
ggsave("acc_model_CC_100B.png", width = 5, height = 5,dpi = 300)
ggsave("acc_model_Exp_100B.png", width = 5, height = 5,dpi = 300)

#manually enter fixed effect estimates from your model summary
effects <- c(task_SvMv = 1.7656,
             task_SvMt = 0.8263,
             task_SvMvt = 2.7442 ,
             exemplar_Learned = 0.4102)
#convert log-odds to probabilities using invlogit
probabilities <- invlogit(effects)
#create data frame
results <- data.frame(
  Effect = names(effects),
  Log_Odds = effects,
  Predicted_Accuracy = round(probabilities, 3)
)
write.csv(results, "acc_logit_table_noint_100B.csv", row.names = FALSE)

#bar Plot
cbPalette <- brewer.pal(8, "Paired") # 8 colors from the Dark2, Set1, Set2, or Paired palette for colorblind
ggplot(results, aes(x = Effect, y = Predicted_Accuracy, fill = Effect)) +
  geom_bar(stat = "identity", color = "black") +
  geom_text(aes(label = Predicted_Accuracy), vjust = -0.5) +
  ylim(0, 1) +
  labs(title = "A)",
       y = "Predicted Accuracy (invlogit)",
       x = "Effect") +
  scale_fill_manual(values = cbPalette) +  # Apply colorblind-friendly palette
  theme_apa() +  # No grid background
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1, color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title.x = element_text(color = "black"),
    axis.title.y = element_text(color = "black"),
    axis.line = element_line(color = "black", linewidth = 0.50),  # Set axis lines to black
    plot.title = element_text(hjust = 0.5, size = 14),
    panel.grid = element_blank()  # Remove grid lines
  )
ggsave("predicted_accuracy_plot_noint_100B.png", width = 5, height =5,dpi = 300 )

#summary of the model
#install.packages("gtsummary")
library(gtsummary)

model2 %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "int_model_table_100Block.png"
  )

model2_noint %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "full_model_table_100Block.png"
  )

####100_R####
acc_data_100R <- test_filtered_dataset_100_R 
#prep dataset for models
acc_data_100R$ID <- factor(acc_data_100R$ID)
levels(acc_data_100R$ID)
acc_data_100R$exemplar <- as.factor(acc_data_100R$exemplar)
levels(acc_data_100R$exemplar)
acc_data_100R$exemplar <- factor(acc_data_100R$exemplar, levels = c("Not learned", "Learned"))
acc_data_100R$task <- as.factor(acc_data_100R$task)
levels(acc_data_100R$task) 
#paper
levels(acc_data_100R$task) <- c("Sv", "SvMt","SvMv", "SvMvt")
acc_data_100R$task <- factor(acc_data_100R$task, levels = c("Sv", "SvMv","SvMt", "SvMvt"))
levels(acc_data_100R$task) 

#test accuracy & generalisation
model1_r <- glmer(
  accuracy ~ 1 + task + exemplar + task:exemplar +
    (1 + task + exemplar + task:exemplar | ID),
  data = acc_data_100R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model1_r)
"boundary (singular) fit: see help('isSingular')"
#the interaction effect in the slope it's making the model not converging (fit isSingular)

#model with no interaction effect in the slope
model2_r <- glmer(
  accuracy ~ 1 + task + exemplar + task:exemplar +
    (1+ task + exemplar | ID),
  data = acc_data_100R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model2_r)
"optimizer (bobyqa) convergence code: 0 (OK)
boundary (singular) fit: see help('isSingular')"

#the task effect in the slope it's making the model not converging (fit isSingular)
model3_r <- glmer(
  accuracy ~ 1+ task + exemplar + task:exemplar +
    (1 + exemplar| ID),
  data = acc_data_100R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model3_r)
model3_noint_r <- glmer(
  accuracy ~ 1 + task + exemplar +
    (1 + exemplar| ID),
  data = acc_data_100R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model3_noint_r)
anova(model3_r,model3_noint_r)
"               npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
model3_noint_r    8 7686.8 7741.3 -3835.4    7670.8                     
model3_r         11 7691.3 7766.3 -3834.7    7669.3 1.4696  3     0.6893"
#interaction doesn't explain the model better, no better fit to the data

#check main effects
model3_noint_r2 <- glmer(
  accuracy ~ 1 + task +
    (1 + exemplar| ID),
  data = acc_data_100R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model3_noint_r2)
anova(model3_noint_r2,model3_noint_r)
#main effect task
"                npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)   
model3_noint_r2    5 7693.0 7727.1 -3841.5    7683.0                        
model3_noint_r     8 7686.8 7741.3 -3835.4    7670.8 12.219  3   0.006669 **"
#main effect exemplar
"                npar    AIC    BIC  logLik -2*log(L) Chisq Df Pr(>Chisq)   
model3_noint_r2    7 7692.9 7740.6 -3839.4    7678.9                       
model3_noint_r     8 7686.8 7741.3 -3835.4    7670.8 8.075  1   0.004488 **"

"FINAL MODEL -> model3_noint_r"

#post-hoc comparisons
post_learn = emmeans(model3_noint_r, pairwise~exemplar, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn
"TASK
 contrast                                              odds.ratio     SE  df null z.ratio p.value
 Shape / (Shape + Visual Motion)                            0.806 0.0638 Inf    1  -2.725  0.0386
 Shape / (Shape + Tactile Motion)                           0.845 0.0665 Inf    1  -2.141  0.1937
 Shape / (Shape + Motion + Tactile)                         0.772 0.0608 Inf    1  -3.287  0.0061
 (Shape + Visual Motion) / (Shape + Tactile Motion)         1.048 0.0817 Inf    1   0.602  1.0000
 (Shape + Visual Motion) / (Shape + Motion + Tactile)       0.958 0.0747 Inf    1  -0.556  1.0000
 (Shape + Tactile Motion) / (Shape + Motion + Tactile)      0.914 0.0709 Inf    1  -1.165  1.0000
EXEMPLAR
contrast              odds.ratio    SE  df null z.ratio p.value
 Not learned / Learned      0.597 0.105 Inf    1  -2.920  0.0035"
results_CI_learn <- 
  confint(results_learn)
results_CI_learn
" TASK
 contrast                                              odds.ratio     SE  df asymp.LCL asymp.UCL
 Shape / (Shape + Visual Motion)                            0.806 0.0638 Inf     0.654     0.993
 Shape / (Shape + Tactile Motion)                           0.845 0.0665 Inf     0.686     1.040
 Shape / (Shape + Motion + Tactile)                         0.772 0.0608 Inf     0.627     0.950
 (Shape + Visual Motion) / (Shape + Tactile Motion)         1.048 0.0817 Inf     0.853     1.287
 (Shape + Visual Motion) / (Shape + Motion + Tactile)       0.958 0.0747 Inf     0.779     1.176
 (Shape + Tactile Motion) / (Shape + Motion + Tactile)      0.914 0.0709 Inf     0.745     1.121
EXEMPLAR
 contrast              odds.ratio    SE  df asymp.LCL asymp.UCL
 Not learned / Learned      0.597 0.105 Inf     0.422     0.844 "

model1_r<- plot_model(model3_noint_r)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", size = 0.5) +
  #  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_r
ggsave("acc_model_oddratio_100R.png", width = 5, height = 4, dpi = 300)

model2_r_exemplar<- plot_model(model3_noint_r, type = "eff", terms = c("exemplar"))+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  labs(x ="Exemplar Type",y="Predicted Accuracy (%)", title= "D)")+
  coord_cartesian(ylim = c(0.45,1))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model2_r_exemplar
model2_r_cc
ggsave("acc_model_task_100R.png", width = 5, height = 5,dpi = 300)
ggsave("acc_model_exem_100R.png", width = 5, height = 5,dpi = 300)
ggsave("acc_model_int_100R.png", width = 5, height = 5,dpi = 300)

#check the plot predicted values
ggeffect(model3_noint_r, terms = c("exemplar"), type = 'fe')
"task                     | Predicted |     95% CI
-------------------------------------------------
Shape                    |      0.69 | 0.59, 0.77
Shape + Visual Motion    |      0.73 | 0.64, 0.80
Shape + Tactile Motion   |      0.72 | 0.63, 0.80
Shape + Motion + Tactile |      0.74 | 0.65, 0.81"

"# Predicted probabilities of accuracy

exemplar    | Predicted |     95% CI
------------------------------------
Not learned |      0.65 | 0.59, 0.70
Learned     |      0.76 | 0.65, 0.84"

plot_lmer_accuracy<- plot_model(model3_noint_r, type = "eff", terms = c("task","exemplar")) +
  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  theme_apa()+
  coord_cartesian(ylim = c(0.4,1))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_accuracy
ggsave("acc_model_noint_100R.png", width = 5, height = 5,dpi = 300)

#manually enter fixed effect estimates from your model summary
effects <- c(task_SvMt = 0.16859,
             task_SvMv = 0.21554,
             task_SvMvt = 0.25895,
             exemplar_Learned = 0.51594)
#convert log-odds to probabilities using invlogit
probabilities <- invlogit(effects)
#create data frame
results <- data.frame(
  Effect = names(effects),
  Log_Odds = effects,
  Predicted_Accuracy = round(probabilities, 3)
)
write.csv(results, "acc_logit_table_noint_100R.csv", row.names = FALSE)

#bar Plot
cbPalette <- brewer.pal(8, "Paired") # 8 colors from the Dark2, Set1, Set2, or Paired palette for colorblind
ggplot(results, aes(x = Effect, y = Predicted_Accuracy, fill = Effect)) +
  geom_bar(stat = "identity", color = "black") +
  geom_text(aes(label = Predicted_Accuracy), vjust = -0.5) +
  ylim(0, 1) +
  labs(title = "B)",
       y = "Predicted Accuracy (invlogit)",
       x = "Effect") +
  scale_fill_manual(values = cbPalette) +  # Apply colorblind-friendly palette
  theme_apa() +  # No grid background
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1, color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title.x = element_text(color = "black"),
    axis.title.y = element_text(color = "black"),
    axis.line = element_line(color = "black", size = 0.50),  # Set axis lines to black
    plot.title = element_text(hjust = 0.5, size = 14),
    panel.grid = element_blank()  # Remove grid lines
  )
ggsave("predicted_accuracy_plot_noint_100R.png", width = 5, height = 5,dpi = 300 )

#summary model
model3_r %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "full_model_table_100Random_intereaction.png"
  )

model3_noint_r %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "full_model_table_100Random_noint.png"
  )

Figure1_a<- ggarrange( plot_lmer_accuracy_cc,model2_r_cc, nrow=1, ncol=2)
Figure1_a
Figure1_b<- ggarrange( plot_lmer_accuracy_exemplar, model2_r_exemplar, nrow=1, ncol=2)
Figure1_b
Figure1<- ggarrange(Figure1_a, Figure1_b, nrow=2, ncol=1)
Figure1
ggsave("Figure1.png", width = 8, height = 10,dpi = 300 )

####78_B####
acc_data_78_B <- test_filtered_dataset_78_B 
#prep dataset for models
acc_data_78_B$ID <- factor(acc_data_78_B$ID)
acc_data_78_B$exemplar <- as.factor(acc_data_78_B$exemplar)
levels(acc_data_78_B$exemplar)
#####acc_data_78_B$exemplar <- factor(acc_data_78_B$exemplar, levels = c("Not learned", "Learned"))
acc_data_78_B$task <- as.factor(acc_data_78_B$task)
levels(acc_data_78_B$task)
#paper
levels(acc_data_78_B$task) <- c("Sv", "SvMt","SvMv", "SvMvt")
acc_data_78_B$task <- factor(acc_data_78_B$task, levels = c("Sv", "SvMv","SvMt", "SvMvt"))

#test accuracy & generalisation
#the interaction effect in the slope it's making the model not converging (fit isSingular)
#model with no interaction effect in the slope is not in converging as well
model2_78b <- glmer(
  accuracy ~ 1 + task + exemplar + task:exemplar +
    (1 + task + exemplar | ID),
  data = acc_data_78_B,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model2_78b)
"optimizer (bobyqa) convergence code: 0 (OK)
boundary (singular) fit: see help('isSingular')"

#model converged
model3_78b <- glmer(
  accuracy ~ 1 + task + exemplar+ task:exemplar +
    (1 + task | ID),
  data = acc_data_78_B,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model3_78b)
model3_noint_78b <- glmer(
  accuracy ~ 1 + task + exemplar+ 
    (1 + task | ID),
  data = acc_data_78_B,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model3_noint_78b)
anova(model3_78b,model3_noint_78b)
"                 npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)  
model3_noint_78b   15 6273.4 6376.7 -3121.7    6243.4                       
model3_78b         18 6270.3 6394.2 -3117.2    6234.3 9.0927  3    0.02808 *"

#post-hoc comparisons
post_learn = emmeans(model3_78b, ~ exemplar*task, type = 'response', adjust = 'bonferroni')
levels(post_learn)
#"> levels(post_learn)
# task - [1] "Shape"   "Shape + Visual Motion"    "Shape + Tactile Motion"  "Shape + Motion + Tactile"
# exemplar [1] "Learned"     "Not learned""
results_learn <- summary(contrast(post_learn))
results_learn
" TASK * exemplar
contrast                                      odds.ratio     SE  df null z.ratio p.value
 Shape Learned effect                               0.237 0.0503 Inf    1  -6.784  <.0001*
 (Shape + Visual Motion Learned) effect             0.570 0.1300 Inf    1  -2.464  0.0183*
 (Shape + Tactile Motion Learned) effect            1.589 0.2770 Inf    1   2.660  0.0125*
 (Shape + Motion + Tactile Learned) effect          4.832 1.6400 Inf    1   4.642  <.0001*
 Shape Not learned effect                           0.221 0.0482 Inf    1  -6.922  <.0001*
 (Shape + Visual Motion Not learned) effect         0.770 0.1830 Inf    1  -1.103  0.2815
 (Shape + Tactile Motion Not learned) effect        1.218 0.2230 Inf    1   1.077  0.2815
 (Shape + Motion + Tactile Not learned) effect      4.658 1.6300 Inf    1   4.401  <.0001*
"
results_CI_learn <- confint(contrast(post_learn))
results_CI_learn
" TASK * exemplar
contrast                                      odds.ratio     SE  df asymp.LCL asymp.UCL
 Shape Learned effect                               0.237 0.0503 Inf     0.132     0.423
 (Shape + Visual Motion Learned) effect             0.570 0.1300 Inf     0.306     1.064
 (Shape + Tactile Motion Learned) effect            1.589 0.2770 Inf     0.987     2.557
 (Shape + Motion + Tactile Learned) effect          4.832 1.6400 Inf     1.911    12.222
 Shape Not learned effect                           0.221 0.0482 Inf     0.122     0.402
 (Shape + Visual Motion Not learned) effect         0.770 0.1830 Inf     0.402     1.473
 (Shape + Tactile Motion Not learned) effect        1.218 0.2230 Inf     0.739     2.007
 (Shape + Motion + Tactile Not learned) effect      4.658 1.6300 Inf     1.791    12.113
"

model1_78b<- plot_model(model3_78b)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", size = 0.5) +
  #  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_78b
ggsave("acc_model_oddratio_78B.png", width = 7, height = 5, dpi = 300)

model2_78b<- plot_model(model3_78b, type = "eff", terms = c("exemplar","task"))+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  labs(x ="Exemplar",y="Predicted Accuracy (%)", title= "A)")+
  coord_cartesian(ylim = c(0.45,1))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model2_78b
ggsave("acc_model_int_78B.png", width = 5, height = 5,dpi = 300)

model2_78b_2<- plot_model(model3_78b, type = "eff", terms = c("task", "exemplar"))+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  coord_cartesian(ylim = c(0.4,1))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model2_78b_2
ggsave("acc_model_int_78B.png", width = 5, height = 5,dpi = 300)

#check the plot predicted values
ggeffect(model3_78b, terms = c("task", "exemplar"), type = 'fe')
"exemplar: Learned
task                     | Predicted |     95% CI
-------------------------------------------------
Shape                    |      0.61 | 0.56, 0.66
Shape + Visual Motion    |      0.79 | 0.69, 0.86
Shape + Tactile Motion   |      0.91 | 0.85, 0.95
Shape + Motion + Tactile |      0.97 | 0.92, 0.99

exemplar: Not learned
task                     | Predicted |     95% CI
-------------------------------------------------
Shape                    |      0.60 | 0.54, 0.65
Shape + Visual Motion    |      0.84 | 0.75, 0.90
Shape + Tactile Motion   |      0.89 | 0.82, 0.94
Shape + Motion + Tactile |      0.97 | 0.92, 0.99"

#manually enter fixed effect estimates from your model summary
effects <- c(task_SvMt =  1.90478,
             task_SvMv =   0.87981       ,
             task_SvMtv = 3.01704    ,
             exemplar_NotLearned = -0.06635    ,
             int_SvMv_Notlearned =0.36632,
             int_SvMt_Notlearned= -0.19984,
             int_SvMtv_Notlearned= 0.02955)
#convert log-odds to probabilities using invlogit
probabilities <- invlogit(effects)
#create data frame
results <- data.frame(
  Effect = names(effects),
  Log_Odds = effects,
  Predicted_Accuracy = round(probabilities, 3)
)
write.csv(results, "acc_logit_table_noint_78B.csv", row.names = FALSE)

#bar Plot
cbPalette <- brewer.pal(8, "Paired") # 8 colors from the Dark2, Set1, Set2, or Paired palette for colorblind
ggplot(results, aes(x = Effect, y = Predicted_Accuracy, fill = Effect)) +
  geom_bar(stat = "identity", color = "black") +
  geom_text(aes(label = Predicted_Accuracy), vjust = -0.5) +
  ylim(0, 1) +
  labs(title = "A)",
       y = "Predicted Accuracy (invlogit)",
       x = "Effect") +
  scale_fill_manual(values = cbPalette) +  # Apply colorblind-friendly palette
  theme_apa() +  # No grid background
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1, color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title.x = element_text(color = "black"),
    axis.title.y = element_text(color = "black"),
    axis.line = element_line(color = "black", size = 0.50),  # Set axis lines to black
    plot.title = element_text(hjust = 0.5, size = 14),
    panel.grid = element_blank()  # Remove grid lines
  )
ggsave("predicted_accuracy_plot_int_78B.png", width = 6, height = 6,dpi = 300 )

ggplot(results_CI_learn, aes(x = contrast, y = odds.ratio, ymin = asymp.LCL, ymax = asymp.UCL)) +
  geom_pointrange(color = "darkblue") +
  geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
  coord_flip() +
  labs(
    title = "Contrasts of Task and Exemplar Conditions",
    x = "Contrast",
    y = "Odds Ratio (Log Scale)"
  ) +
  scale_y_log10() +
  theme_apa() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )
ggsave("Contrasts of Task and Exemplar Conditions_78B.png", width = 6, height = 6,dpi = 300 )

#summary model
model3_78b %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "full_model_table_78Block.png"
  )
model3_noint_78b %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "full_model_table_78Block_noiny.png"
  )

####78_R####
acc_data_78_R <- test_filtered_dataset_78_R 
#prep dataset for models
acc_data_78_R$ID <- factor(acc_data_78_R$ID)
acc_data_78_R$exemplar <- as.factor(acc_data_78_R$exemplar)
levels(acc_data_78_R$exemplar)
#####acc_data_78_R$exemplar <- factor(acc_data_78_R$exemplar, levels = c("Not learned", "Learned"))
acc_data_78_R$task <- as.factor(acc_data_78_R$task)
levels(acc_data_78_R$task)
#paper
levels(acc_data_78_R$task) <- c("Sv", "SvMt","SvMv", "SvMvt")
acc_data_78_R$task <- factor(acc_data_78_R$task, levels = c("Sv", "SvMv","SvMt", "SvMvt"))

#test accuracy & generalisation
#the interaction effect in the slope it's making the model not converging (fit isSingular)
#model with no interaction effect in the slope its not converging as well
model2_78r <- glmer(
  accuracy ~ 1 + task + exemplar + task:exemplar +
    (1 + task + exemplar | ID),
  data = acc_data_78_R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model2_78r)
"optimizer (bobyqa) convergence code: 0 (OK)
boundary (singular) fit: see help('isSingular')"
model3_78r <- glmer(
  accuracy ~ 1 + task + exemplar+ task:exemplar +
    (1 + task | ID),
  data = acc_data_78_R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model3_78r)
"optimizer (bobyqa) convergence code: 0 (OK)
boundary (singular) fit: see help('isSingular') "

model4_78r <- glmer(
  accuracy ~ 1 + task + exemplar+ task:exemplar +
    (1 + exemplar | ID),
  data = acc_data_78_R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model4_78r)
"optimizer (bobyqa) convergence code: 0 (OK)
boundary (singular) fit: see help('isSingular') "

#model converged
model5_78r <- glmer(
  accuracy ~ 1 + task + exemplar + task:exemplar + 
    (1 | ID),
  data = acc_data_78_R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5))
)
summary(model5_78r)
model5_no_int_78r <- glmer(
  accuracy ~ 1 + task + exemplar+ 
    (1| ID),
  data = acc_data_78_R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model5_no_int_78r)
anova(model5_78r,model5_no_int_78r)
"model5_no_int_78r: accuracy ~ 0 + task + exemplar + (1 | ID)
model5_78r: accuracy ~ 0 + task + exemplar + task:exemplar + (1 | ID)
                  npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
model5_no_int_78r    6 8340.5 8381.5 -4164.3    8328.5                     
model5_78r           9 8345.8 8407.3 -4163.9    8327.8 0.7332  3     0.8654"
#interaction doesn't explain the model better, no better fit to the data
#check main effects
model5_no_int_78r_2<- glmer(
  accuracy ~ 1 + task + 
    (1| ID),
  data = acc_data_78_R,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model5_no_int_78r_2)
anova(model5_no_int_78r_2,model5_no_int_78r)
#TASK
"                    npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model5_no_int_78r_2    3 8611.2 8631.7 -4302.6    8605.2                         
model5_no_int_78r      6 8340.5 8381.5 -4164.3    8328.5 276.72  3  < 2.2e-16 ***"
#EXEMPLAR - NONE
"                    npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
model5_no_int_78r_2    5 8339.5 8373.6 -4164.7    8329.5                     
model5_no_int_78r      6 8340.5 8381.5 -4164.3    8328.5 0.9527  1      0.329"

correct_model_78R<- glmer(
    accuracy ~ 1 + task + 
      (1| ID),
    data = acc_data_78_R,
    family = binomial(link = "logit"),
    control = glmerControl(optimizer = "bobyqa",
                           optCtrl = list(maxfun = 2e5)))
summary(correct_model_78R)

#post-hoc comparisons
post_learn = emmeans(correct_model_78R, pairwise~task, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn
" Shape / (Shape + Visual Motion)                            0.617 0.0447 Inf    1  -6.666  <.0001
 Shape / (Shape + Tactile Motion)                           0.455 0.0336 Inf    1 -10.669  <.0001
 Shape / (Shape + Motion + Tactile)                         0.299 0.0230 Inf    1 -15.696  <.0001
 (Shape + Visual Motion) / (Shape + Tactile Motion)         0.736 0.0546 Inf    1  -4.127  0.0002
 (Shape + Visual Motion) / (Shape + Motion + Tactile)       0.484 0.0373 Inf    1  -9.407  <.0001
 (Shape + Tactile Motion) / (Shape + Motion + Tactile)      0.657 0.0515 Inf    1  -5.354  <.0001"
results_CI_learn <- 
  confint(results_learn)
results_CI_learn
" contrast                                              odds.ratio     SE  df asymp.LCL asymp.UCL
 Shape / (Shape + Visual Motion)                            0.617 0.0447 Inf     0.510     0.747
 Shape / (Shape + Tactile Motion)                           0.455 0.0336 Inf     0.374     0.552
 Shape / (Shape + Motion + Tactile)                         0.299 0.0230 Inf     0.244     0.366
 (Shape + Visual Motion) / (Shape + Tactile Motion)         0.736 0.0546 Inf     0.605     0.895
 (Shape + Visual Motion) / (Shape + Motion + Tactile)       0.484 0.0373 Inf     0.395     0.593
 (Shape + Tactile Motion) / (Shape + Motion + Tactile)      0.657 0.0515 Inf     0.534     0.808"

model1_78r<- plot_model(correct_model_78R)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", size = 0.5) +
  #  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_78r
ggsave("acc_model_oddratio_78R.png", width = 5, height = 4, dpi = 300)

model2_78r<- plot_model(model5_no_int_78r, type = "eff", terms = c("task","exemplar"))+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  coord_cartesian(ylim = c(0.4,1))
model2_78r
ggsave("acc_model_int_78R.png", width = 5, height = 5,dpi = 300)

#check the plot predicted values
ggeffect(correct_model_78R, terms = c("task"), type = 'fe')
"task                     | Predicted |     95% CI
-------------------------------------------------
Shape                    |      0.52 | 0.45, 0.58
Shape + Visual Motion    |      0.63 | 0.57, 0.69
Shape + Tactile Motion   |      0.70 | 0.65, 0.75
Shape + Motion + Tactile |      0.78 | 0.73, 0.82"

plot_lmer_accuracy<- plot_model(correct_model_78R, type = "eff", terms = c("task")) +
  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "B)")+
  theme_apa()+
  coord_cartesian(ylim = c(0.45,1))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_accuracy
ggsave("acc_model_noint_78R.png", width = 5, height = 5,dpi = 300)

summary(correct_model_78R)
#manually enter fixed effect estimates from your model summary
effects <- c(task_SvMt = 0.78841 ,
             task_SvMv=  0.48220,
             task_SvMvt=  1.20820 )
#convert log-odds to probabilities using invlogit
probabilities <- invlogit(effects)
#create data frame
results <- data.frame(
  Effect = names(effects),
  Log_Odds = effects,
  Predicted_Accuracy = round(probabilities, 3)
)
write.csv(results, "acc_logit_table_noint_78R.csv", row.names = FALSE)

#bar Plot
cbPalette <- brewer.pal(8, "Paired") # 8 colors from the Dark2, Set1, Set2, or Paired palette for colorblind
ggplot(results, aes(x = Effect, y = Predicted_Accuracy, fill = Effect)) +
  geom_bar(stat = "identity", color = "black") +
  geom_text(aes(label = Predicted_Accuracy), vjust = -0.5) +
  ylim(0, 1) +
  labs(title = "B)",
       y = "Predicted Accuracy (invlogit)",
       x = "Effect") +
  scale_fill_manual(values = cbPalette) +  # Apply colorblind-friendly palette
  theme_apa() +  # No grid background
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1, color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title.x = element_text(color = "black"),
    axis.title.y = element_text(color = "black"),
    axis.line = element_line(color = "black", size = 0.50),  # Set axis lines to black
    plot.title = element_text(hjust = 0.5, size = 14),
    panel.grid = element_blank()  # Remove grid lines
  )
ggsave("predicted_accuracy_plot_noint_78R.png", width = 5, height = 5,dpi = 300 )

#summary model
correct_model_78R%>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "final_model_table_78R.png"
  )

model5_no_int_78r %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "full_model_table_78R.png"
  )

model5_78r %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "interaction_model_table_78R.png"
  )


Figure2<- ggarrange(model2_78b_2,plot_lmer_accuracy, nrow=1, ncol=2)
Figure2
ggsave("Figure4.png", width = 8, height = 6,dpi = 300 )

####100_B_LS####
acc_data_LS <- test_filtered_dataset_100_B_LS 
#prep dataset for models
acc_data_LS$ID <- factor(acc_data_LS$ID)
acc_data_LS$exemplar <- as.factor(acc_data_LS$exemplar)
levels(acc_data_LS$exemplar)
acc_data_LS$exemplar <- factor(acc_data_LS$exemplar, levels = c("Not learned", "Learned"))
acc_data_LS$task <- as.factor(acc_data_LS$task)
levels(acc_data_LS$task)
#paper
levels(acc_data_LS$task) <- c("Sv", "SvMt","SvMv", "SvMvt")
acc_data_LS$task <- factor(acc_data_LS$task, levels = c("Sv", "SvMv","SvMt", "SvMvt"))

#test accuracy & generalisation
#the interaction effect in the slope it's making the model not converging (fit isSingular)

#model with no interaction effect in the slope
model2_ls <- glmer(
  accuracy ~ 1 + task + exemplar + task:exemplar +
    (1 + task + exemplar | ID),
  data = acc_data_LS,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model2_ls)
"boundary (singular) fit: see help('isSingular')"
model3_ls <- glmer(
  accuracy ~ 1 + task + exemplar + task:exemplar +
    (1 + task  | ID),
  data = acc_data_LS,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model3_ls)
"optimizer (bobyqa) convergence code: 0 (OK)
boundary (singular) fit: see help('isSingular')"

model4_ls <- glmer(
  accuracy ~1 + task + exemplar + task:exemplar +
    (1 + exemplar | ID),
  data = acc_data_LS,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model4_ls)
model4_noint_ls <- glmer(
  accuracy ~ 1 + task + exemplar +
    (1 + exemplar | ID),
  data = acc_data_LS,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model4_noint_ls)
anova(model4_ls,model4_noint_ls)
"model4_noint_ls: accuracy ~ 0 + task + exemplar + (0 + exemplar | ID)
model4_ls: accuracy ~ 0 + task + exemplar + task:exemplar + (0 + exemplar | ID)
                npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
model4_noint_ls    8 4534.5 4589.3 -2259.2    4518.5                     
model4_ls         11 4537.7 4613.1 -2257.9    4515.7 2.7481  3     0.4321"
#interaction doesn't explain the model better, no better fit to the data
#main effects
model4_noint_ls_2 <- glmer(
  accuracy ~ 1 + exemplar +  +
    (1 + exemplar | ID),
  data = acc_data_LS,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(model4_noint_ls_2)
anova(model4_noint_ls_2,model4_noint_ls)
#TASK
"                  npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
model4_noint_ls_2    5 4533.7 4568.0 -2261.9    4523.7                     
model4_noint_ls      8 4534.5 4589.3 -2259.2    4518.5 5.2508  3     0.1543"
#EXEMPLAR
"                  npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model4_noint_ls_2    7 4567.4 4615.4 -2276.7    4553.4                         
model4_noint_ls      8 4534.5 4589.3 -2259.2    4518.5 34.949  1  3.385e-09 ***"

correct_model_100LS <- glmer(
  accuracy ~ 1 + exemplar +  +
    (1 + exemplar | ID),
  data = acc_data_LS,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa",
                         optCtrl = list(maxfun = 2e5)))
summary(correct_model_100LS)

#post-hoc comparisons
post_learn = emmeans(correct_model_100LS, pairwise~exemplar, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn
" contrast              odds.ratio     SE  df null z.ratio p.value
 Not learned / Learned       0.14 0.0373 Inf    1  -7.378  <.0001"
results_CI_learn <- 
  confint(results_learn)
results_CI_learn
" contrast              odds.ratio     SE  df asymp.LCL asymp.UCL
 Not learned / Learned       0.14 0.0373 Inf    0.0831     0.236"

model1_ls<- plot_model(model4_noint_ls)+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", size = 0.5) +
  #  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model1_ls
ggsave("acc_model_oddratio_LS.png", width = 5, height = 4, dpi = 300)

model2_ls<- plot_model(model4_noint_ls, type = "eff", terms = c("task","exemplar"))+
  #geom_bar(stat = "identity", color = "black") +
  theme_apa()+
  labs(x ="Cue Condition",y="Predicted Accuracy (%)", title= "A)")+
  coord_cartesian(ylim = c(0.4,1))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
model2_ls
ggsave("acc_model_int_LS.png", width = 5, height = 5,dpi = 300)

#check the plot predicted values
ggeffect(correct_model_100LS, terms = c("exemplar"), type = 'fe')
"exemplar    | Predicted |     95% CI
------------------------------------
Not learned |      0.76 | 0.70, 0.81
Learned     |      0.96 | 0.91, 0.98"

plot_lmer_accuracy<- plot_model(correct_model_100LS, type = "eff", terms = c("exemplar"), dot.size = 5, line.size = 0.5, alpha = 0.3) +
  labs(x ="Exemplar",y="Predicted Accuracy (%)", title= "A)")+
  theme_apa()+
  coord_cartesian(ylim = c(0.45,1))+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_accuracy
ggsave("acc_model_noint_LS_exemplar.png", width = 5, height = 5,dpi = 300)

summary(correct_model_100LS)
#manually enter fixed effect estimates from your model summary
effects_effect <- c(exemplar_Learned = 1.9655)

effects <- c(task_SvMv=    -0.07788 ,
             task_SvMt=0.13356 ,
             task_SvMvt=0.11819     ,
             exemplarLearned =1.96672)
#convert log-odds to probabilities using invlogit
probabilities <- invlogit(effects)
#create data frame
results <- data.frame(
  Effect = names(effects),
  Log_Odds = effects,
  Predicted_Accuracy = round(probabilities, 3)
)
write.csv(results, "acc_logit_table_noint_LS.csv", row.names = FALSE)

#bar Plot
cbPalette <- brewer.pal(8, "Paired") # 8 colors from the Dark2, Set1, Set2, or Paired palette for colorblind
ggplot(results, aes(x = Effect, y = Predicted_Accuracy, fill = Effect)) +
  geom_bar(stat = "identity", color = "black") +
  geom_text(aes(label = Predicted_Accuracy), vjust = -0.5) +
  ylim(0, 1) +
  labs(title = "B)",
       y = "Predicted Accuracy (invlogit)",
       x = "Effect") +
  scale_fill_manual(values = cbPalette) +  # Apply colorblind-friendly palette
  theme_apa() +  # No grid background
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1, color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title.x = element_text(color = "black"),
    axis.title.y = element_text(color = "black"),
    axis.line = element_line(color = "black", size = 0.50),  # Set axis lines to black
    plot.title = element_text(hjust = 0.5, size = 14),
    panel.grid = element_blank()  # Remove grid lines
  )
ggsave("predicted_accuracy_plot_noint_100R.png", width = 5, height = 5,dpi = 300 )

#summary model
model4_noint_ls %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "fullfactors_model_table_100B_LS.png"
  )
correct_model_100LS%>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "exemplar_model_table_100B_LS.png"
  )
####difference score#####
# Load necessary packages
colnames(acc_data_100R)[6] <- 'exp'
combined_data <- bind_rows(acc_data, acc_data_100R, acc_data_78_B, acc_data_78_R, .id = "experiment")
levels(combined_data$task)
combined_data$experiment<- as.factor(combined_data$experiment)
levels(combined_data$experiment) <- c("Exp 1a", "Exp 1b", "Exp 2a", "Exp 2b")

#process the data to calculate difference scores
combined_data_processed <- combined_data %>%
  group_by(ID, experiment, task, exemplar) %>%  # Group by participant (ID), experiment, task, and exemplar
  summarise(accuracy = mean(accuracy, na.rm = TRUE), .groups = 'drop') %>%
  pivot_wider(names_from = task, values_from = accuracy) %>%
  mutate(
    Diff_Shape = `Shape + Motion + Tactile` - Shape,
    Diff_Shape_VisualMotion = `Shape + Motion + Tactile` - `Shape + Visual Motion`,
    Diff_Shape_TactileMotion = `Shape + Motion + Tactile` - `Shape + Tactile Motion`
  ) %>%
  pivot_longer(cols = starts_with("diff"),
               names_to = "condition",
               values_to = "difference_score")
head(combined_data_processed)

levels(combined_data_processed$exemplar)
#boxplot to visualize the difference scores
ggplot(combined_data_processed, aes(x = condition, y = difference_score, fill = exemplar)) +
  geom_boxplot() +  # Boxplot to show the distribution
  geom_jitter(width = 0.2, size = 2, alpha = 0.5, aes(color = exemplar)) +  # Jittered points for individual scores
  facet_wrap(~experiment) +  # Facet by experiment
  theme_apa() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", size = 1) + # Horizontal line at 0
  labs(title = "Difference Scores Across Experiments",
       x = "Cue Condition",
       y = "Difference Score") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_manual(values = c("salmon","lightblue")) +  # Custom colors for exemplar
  scale_color_manual(values = c("salmon","lightblue"))  # Custom colors for points
ggsave("diff_score_boxplot_plot.png", width = 7, height = 7,dpi = 300)

#violin plot with dot plot to visualize the distribution and individual points
ggplot(combined_data_processed, aes(x = condition, y = difference_score, fill = exemplar)) +
  geom_violin(trim = FALSE, alpha = 0.3) +  # Violin plot for distribution
  geom_jitter(width = 0.2, size = 2, alpha = 0.6, aes(color = exemplar)) +  # Dot plot with jitter for individual scores
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", size = 1) + # Horizontal line at 0
  facet_wrap(~experiment) +  # Facet by experiment
  theme_apa() +
  labs(title = "Difference Scores Across Experiments",
       x = "Cue Condition",
       y = "Difference Score") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_manual(values = c("salmon","lightblue")) +  # Custom colors for exemplar
  scale_color_manual(values = c("salmon","lightblue"))  # Custom colors for points
ggsave("diff_score_violin_plot.png", width = 7, height = 7,dpi = 300)

# prepfor model
combined_data_processed$exp <- as.factor(combined_data_processed$exp)
combined_data_processed$condition <- as.factor(combined_data_processed$condition)
write.csv(combined_data_processed, "combined_data_processed_diffscore.csv", row.names = FALSE)

# Fit the mixed-effects model
model <- lmer(difference_score ~ exp * condition + 
                (1|ID), 
              data = combined_data_processed)
model2 <- lmer(difference_score ~ exp + condition + 
                 (1|ID), 
               data = combined_data_processed)
anova(model,model2)
"Data: combined_data_processed
Models:
model2: difference_score ~ exp + condition + (1 | ID)
model: difference_score ~ exp * condition + (1 | ID)
       npar     AIC     BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
model2    8 -717.43 -679.44 366.71   -733.43                         
model    14 -746.58 -680.10 387.29   -774.58 41.155  6    2.7e-07 ***"

plot_lmer_accuracy<- plot_model(model, type = "eff", terms = c("exp","condition"), dot.size = 5, line.size = 0.5, alpha = 0.3) +
  #geom_bar(stat = "identity", color = "black") +
  geom_line()+
 # geom_hline(yintercept = 0, linetype = "solid", color = "black", size = 0.75) + # Horizontal line at 0
  labs(x ="Experiment",y="Predicted Difference score", title= "Difference score (3cues - condition)")+
  theme_apa()+
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1)) 
plot_lmer_accuracy
ggsave("plot_model_diff_score.png", width = 7, height = 5,dpi = 300)


#post-hoc comparisons
post_learn = emmeans(model, ~exp*condition, type = 'response', adjust = 'bonferroni')
levels(post_learn)
#$exp [1] "100_block"       "100_interleaved" "78_block"        "78_interleaved" 
#$condition [1] "diff_shape"        "diff_shape_haptic" "diff_shape_motion"
results_learn <- summary(contrast(post_learn))
results_learn
" contrast                                estimate     SE  df t.ratio p.value
 100_block diff_shape effect               0.0788 0.0207 281   3.799  0.0004*
 100_random diff_shape effect             -0.0569 0.0238 309  -2.384  0.0304*
 78_block diff_shape effect                0.1718 0.0233 299   7.361  <.0001*
 78_interleaved diff_shape effect          0.1368 0.0236 307   5.810  <.0001*
 100_block diff_shape_haptic effect       -0.0265 0.0207 281  -1.276  0.2437
 100_random diff_shape_haptic effect      -0.0968 0.0236 301  -4.098  0.0002*
 78_block diff_shape_haptic effect        -0.0607 0.0233 299  -2.602  0.0195*
 78_interleaved diff_shape_haptic effect  -0.0384 0.0233 299  -1.644  0.1350
 100_block diff_shape_motion effect       -0.0450 0.0207 281  -2.170  0.0463*
 100_random diff_shape_motion effect      -0.1094 0.0236 301  -4.630  <.0001*
 78_block diff_shape_motion effect         0.0236 0.0233 299   1.012  0.3367
 78_interleaved diff_shape_motion effect   0.0225 0.0234 302   0.962  0.3367
"
results_CI_learn <- confint(contrast(post_learn))
results_CI_learn
"contrast                                 estimate     SE  df lower.CL upper.CL
 100_block diff_shape effect                0.0771 0.0217 249   0.0142  0.13989
 100_interleaved diff_shape effect         -0.0479 0.0292 287  -0.1321  0.03636
 78_block diff_shape effect                 0.1700 0.0243 265   0.0997  0.24037
 78_interleaved diff_shape effect           0.1350 0.0246 272   0.0641  0.20601
 100_block diff_shape_haptic effect        -0.0282 0.0217 249  -0.0911  0.03461
 100_interleaved diff_shape_haptic effect  -0.0965 0.0292 287  -0.1808 -0.01230
 78_block diff_shape_haptic effect         -0.0625 0.0243 265  -0.1328  0.00787
 78_interleaved diff_shape_haptic effect   -0.0401 0.0243 265  -0.1105  0.03023
 100_block diff_shape_motion effect        -0.0468 0.0217 249  -0.1096  0.01606
 100_interleaved diff_shape_motion effect  -0.1027 0.0292 287  -0.1869 -0.01845
 78_block diff_shape_motion effect          0.0219 0.0243 265  -0.0485  0.09221
 78_interleaved diff_shape_motion effect    0.0208 0.0244 268  -0.0498  0.09136"
