###for general functions####
library(broom)
library(car)
library(caret)
library(plyr)
library(psych)
library(tidyverse)
library(dplyr)
library(reshape2)
library(qwraps2) 
library(devtools)
library(tidytext)
library(rstatix)
library(fmsb)
library(rcompanion)
library(Rmisc)
#for plotting
library(cowplot)
library(dotwhisker)
library(GGally)
library(ggeffects)
library(gridExtra)
library(ggpubr)
library(jtools)
library(sjPlot)
library(effects)
library(latticeExtra)
library(corrplot)
library(RColorBrewer)
library(jcolors)
library(plotly)
library(gplots)
library(ggthemes)
library(ggstance)
library(dplyr)
library(stats)

####Data cleaning####
getwd()
#
setwd("C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_shape78_Block\\data_shape78%")

setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_shape78_Block\\data_shape78%")

#load in datafiles to global environment from working directory - 
#make sure these files are in the same directory then import csv
temp = list.files(pattern="*.csv")
for (i in 1:length(temp)) assign(temp[i], read.csv(temp[i]))
objs <- mget(ls(envir = globalenv()))
dfs <- objs[map_lgl(objs, is.data.frame)]
#merge the different datafiles 
vibration_data <- reduce(dfs, full_join)
vibration_data$participant <- as.factor(vibration_data$participant)
table(vibration_data$participant)

setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_shape78_Block\\pilot plots")

#Demographics
names(vibration_data)
#create a list of columns we want called 'cols'
cols <- c('participant', "sex_slider.response","education_slider.response", 'vision_slider.response', 'audition_slider.response')
#match the names in cols to the column names in the datafile and extract them
demog <- vibration_data[cols]
#remove duplicate columns and NA columns 
m_demo1 <- demog[!duplicated(demog), ]
demogfinal <- m_demo1[complete.cases(m_demo1),]
levels(demogfinal$participant)  
demog11 <- demogfinal

colnames(demog11)[1] <- 'ID'
colnames(demog11)[2] <- 'sex'
colnames(demog11)[3] <- 'completed_edu'
colnames(demog11)[4] <- 'problem_vision'
colnames(demog11)[5] <- 'problem_hearing'

demog11$sex <- as.factor(demog11$sex)
demog11$completed_edu <- as.factor(demog11$completed_edu)
demog11$problem_vision <- as.factor(demog11$problem_vision)
demog11$problem_hearing <- as.factor(demog11$problem_hearing)

write.table(demog11, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_shape78_Block\\df\\demographics.csv",  sep= ",")

#logic
demographics$sex <- as.factor(demographics$sex)
demographics$completed_edu <- as.factor(demographics$completed_edu)
demographics$problem_vision <- as.factor(demographics$problem_vision)
demographics$problem_hearing <- as.factor(demographics$problem_hearing)

levels(demographics$sex)# <- c('Male', 'Female')
levels(demographics$problem_vision) #<-  c('Yes')
levels(demographics$problem_hearing)# <-  c('Yes')
levels(demographics$completed_edu)# <-  c('Primary School','Secondary School', 'Third level or higher')

demographic_summary <-demog %>%
  group_by(ID, sex) %>%
  summarise(age=mean(age))

summary(demog$sex)
summary(demog$normal_vision)
summary(demog$normal_hearing)
summary(demog$completed_edu)

#Perceptual matching 
names(vibration_data)
cols_disc1<- c("participant","synch","vibration_pm", "test_resp.response", "test_resp.rt")
pm_data <- vibration_data[cols_disc1]
pm_data <- pm_data[!duplicated(pm_data), ]
pm_finaldata <- pm_data[complete.cases(pm_data),]
pm_finaldata$participant <- as.factor(pm_finaldata$participant)
levels(pm_finaldata$participant)  
pm_finaldata$task <- "Perceptual_matching"
colnames(pm_finaldata)[1] <- 'ID'
colnames(pm_finaldata)[2] <- 'SOA'
colnames(pm_finaldata)[3] <- 'vibration'
colnames(pm_finaldata)[4] <- 'percevied_sync'
colnames(pm_finaldata)[5] <- 'RTms'
pm_finaldata$RTms <- pm_finaldata$RTms*1000

pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
levels(pm_finaldata$SOA) <- c("150ms SOA", "300ms SOA", "no SOA")
pm_finaldata$SOA <- factor(pm_finaldata$SOA, levels=c("no SOA","150ms SOA", "300ms SOA"))
pm_finaldata$vibration<- as.factor(pm_finaldata$vibration)
levels(pm_finaldata$vibration) <- c( "360rotation", "360rotation", "360rotation", "jump" , "jump"  , "jump", 
                                     "swing","swing","swing","vibration", "vibration",   "vibration" )
levels(pm_finaldata$vibration) <- c("Rotation","Jump" , "Swing", "Vibration")
levels(pm_finaldata$SOA) <- c("No SOA","150ms SOA" ,"300ms SOA")

plotpm <-  ggplot(data = pm_finaldata, aes(x = vibration, y = percevied_sync, col = SOA , group = SOA)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) + 
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  #facet_wrap(~ID) +
  labs(title = "Perceptual Matching Task Performance", x = "Vibration type", y = "Perceived Synchrony") +
  scale_color_manual(values = c( "green","orange","red")) +
  theme_apa()+
  theme(legend.title = element_text("Group"), legend.position = "top")+
  coord_cartesian(ylim = c(1,5))
plotpm
ggsave('SA_78B.jpg', plotpm, width = 6, height = 6, dpi = 300)

write.table(pm_finaldata, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_shape78_Block\\df\\perceptual_matching.csv",  sep= ",")

#anova to check for perceptual matching performance
# 1. Descriptive statistics
pm_finaldata$SOA <- as.factor(pm_finaldata$SOA)
pm_finaldata$percevied_sync
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

# 2. Check for normality of residuals
# Fit a linear model
model <- lm(percevied_sync ~ SOA, data = pm_finaldata)
# Shapiro-Wilk test for normality of residuals - violated
shapiro_test <- shapiro.test(residuals(model))
print(shapiro_test)
"	Shapiro-Wilk normality test

data:  residuals(model)
W = 0.93013, p-value = 1.182e-11"
# 3. Check for homogeneity of variances - violated
levene_test <- leveneTest(percevied_sync ~ SOA, data = pm_finaldata)
print(levene_test)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value    Pr(>F)    
group   2  8.1742 0.0003404 ***
      343                      
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1"

summary_stats <- pm_finaldata %>%
  group_by(ID,SOA) %>%
  summarise(
    mean = mean(percevied_sync),
    sd = sd(percevied_sync),
    n = n()
  )
print(summary_stats)

welch_result <- oneway.test(mean ~ SOA, data = summary_stats, var.equal = FALSE)
print(welch_result)
"	One-way analysis of means (not assuming equal variances)

data:  mean and SOA
F = 5.7964, num df = 2.000, denom df = 63.881, p-value = 0.004861"
#post hoc
install.packages("PMCMRplus")
library(PMCMRplus)
games_howell <- gamesHowellTest(mean ~ SOA, data = summary_stats)
print(games_howell)
"Pairwise comparisons using Games-Howell test

             No SOA 150ms SOA
150ms SOA 0.0780    -           
300ms SOA 0.0034    0.4564      

No SOA vs. 150ms SOA: p=0.09 
No SOA vs. 300ms SOA: p= 0.003
150ms SOA vs. 300ms SOA: p=0.46"
# Assuming summary_stats contains calculated means and confidence intervals
# Example structure of summary_stats:
summary_stats <- pm_finaldata %>%
  group_by(SOA) %>%
  summarise(
    mean = mean(percevied_sync, na.rm = TRUE),
    sd = sd(percevied_sync, na.rm = TRUE),
    n = n(),
    se = sd / sqrt(n),  # Standard Error
    ci = qt(0.975, df = n - 1) * se  # 95% Confidence Interval
  )


results <- ggplot(summary_stats, aes(x = SOA, y = mean, fill = SOA)) +
  geom_point(alpha = 0.8) +  # If you want bars
  geom_errorbar(aes(ymin = mean - ci, ymax = mean + ci), width = 0.2, color = "black") +  # Add 95% CI
  stat_summary(geom = "point", size = 4, shape = 21) +  # Add summary points
  theme_apa()+
  labs(
    title = "Perceived Synchrony across SOAony Levels",
    x = "SOAony Levels",
    y = "Perceived Synchrony"
  ) +
  ylim(2,5)+
  annotate("text", x = 1.5, y = max(summary_stats$mean) + 0.5, label = "ns", size = 5, color = "black") +  # No SOA vs. 150ms SOA
  annotate("text", x = 2, y = max(summary_stats$mean) + 1, label = "***", size = 5, color = "black") +    # No SOA vs. 300ms SOA
  annotate("text", x = 2.5, y = max(summary_stats$mean) + 0.2, label = "ns", size = 4, color = "black")   # 150ms SOA vs. 300ms SOA
results
ggsave('perceptual_matching_results.jpg', results, width = 6, height = 6, dpi = 300)

###Learning##
names(vibration_data)
cols_disc2<- c("participant", "category", "exemplar", "shape_percentage", "stim",  "vibration1","prop_learning", "learning_resp.response", "corrAns","learning_resp.rt","learning_trials.thisN")
learning_data <- vibration_data[cols_disc2]
learning_data <- learning_data[!duplicated(learning_data), ]
learning_finaldata <- learning_data[complete.cases(learning_data),]
learning_finaldata$participant <- as.factor(learning_finaldata$participant)
levels(learning_finaldata$participant)  
learning_finaldata$task <- "Learning"
colnames(learning_finaldata)[1] <- 'ID'
colnames(learning_finaldata)[6] <- 'vibration_type'
colnames(learning_finaldata)[8] <- 'response'
colnames(learning_finaldata)[9] <- 'correct_response'
colnames(learning_finaldata)[10] <- 'RTms'
colnames(learning_finaldata)[11] <- 'trial_n'
learning_finaldata$RTms <- learning_finaldata$RTms*1000
learning_finaldata$accuracy <-  ifelse(learning_finaldata$correct_response == learning_finaldata$response, 1,0)
learning_finaldata$trial_n <- learning_finaldata$trial_n +1 

#clean dataset
cols_learning_finaldata.b<- c("ID", "task", "category", "exemplar","shape_percentage", "stim",'vibration_type',"trial_n","prop_learning", "accuracy","RTms") 
learning_finaldata<- learning_finaldata[cols_learning_finaldata.b]
learning_finaldata$category<- as.factor(learning_finaldata$category)
learning_finaldata$exemplar<- as.factor(learning_finaldata$exemplar)
learning_finaldata$stim<- as.factor(learning_finaldata$stim)
learning_finaldata$vibration_type<- as.factor(learning_finaldata$vibration_type)
learning_finaldata$shape_percentage<- as.factor(learning_finaldata$shape_percentage)
levels(learning_finaldata$shape_percentage) <- c("22%", "78%")
learning_finaldata$trial_n<- as.factor(learning_finaldata$trial_n)

#exclusion criteria = below-chance accuracy in 2+ vibration types#
learning_finaldata_excl <- learning_finaldata %>%
  group_by(ID,vibration_type) %>%
  summarise(mean_acc=mean(accuracy),
            mean_rt=mean(RTms))
learning_finaldata_excl$mean_acc <- learning_finaldata_excl$mean_acc*100
# Summarize data and identify participants with 
below_chance_ids <- learning_finaldata_excl %>%
  filter(mean_acc <= 0.50) %>%              # Filter for accuracy below 0.50
  group_by(ID) %>%                          # Group by participant ID
  summarise(below_chance_count = n()) %>%   # Count instances of below-chance accuracy
  filter(below_chance_count >= 2)           # Keep only those with 2+ below-chance conditions
# Display IDs with below-chance performance in 2+ vibration types
below_chance_ids
# List of IDs to exclude
exclude_ids <- c( "6630d342e33ca32f75561f05")
# Exclude these IDs from the original dataset
learning_finaldata_excl_filtered <- learning_finaldata %>%
  filter(!ID %in% exclude_ids)
# View the filtered dataset
learning_finaldata_excl_filtered <-learning_finaldata
table(learning_finaldata_excl_filtered$ID)
levels(learning_finaldata_excl_filtered$vibration_type) <- c("Rotation","Jump" , "Swing", "Vibration")
levels(learning_finaldata_excl_filtered$category) <- c("Category A", "Category B")
levels(learning_finaldata_excl_filtered$shape_percentage)<- c("Learned Uninformative", "Learned Informative")

plot_learning<-  ggplot(data = learning_finaldata_excl_filtered, aes(x = vibration_type, y = accuracy)) +
 stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  geom_hline(yintercept = 0.75, linetype = "dashed", color = "black") +
  geom_hline(yintercept = 0.50, linetype = "dashed", color = "black") +
  #geom_hline(yintercept = 0.25, linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  #facet_wrap(~ID) +
  labs(title = "Percentage Accuracy during Categorisation Learning", x = "Vibration type", y = "Accuracy (%)", fill= "Task") +
  # scale_color_manual(values = c( "#EBA07EFF","#A8554EFF")) +
  theme_apa()+
  theme(legend.title = element_text("Task"), legend.position = "\\")+
  coord_cartesian(ylim = c(0,1))
plot_learning

ggsave('plot_learning2.jpg', plot_learning, width = 8, height = 6, dpi = 300)
ggsave('plot_learning_individual2.jpg', plot_learning, width = 10, height = 8, dpi = 300)

learning_finaldata_excl_filtered$stim <- as.factor(learning_finaldata_excl_filtered$stim)
levels(learning_finaldata_excl_filtered$stim)

plot_l_cat_stim<-  ggplot(data = learning_finaldata_excl_filtered, aes(x = stim, y = accuracy, col = shape_percentage, group = shape_percentage)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
 # stat_summary(geom = 'line', alpha = 0.9, linewidth = 1) +
  geom_hline(yintercept = 0.75, linetype = "dashed", color = "black") +
  geom_hline(yintercept = 0.50, linetype = "dashed", color = "black") +
  geom_vline(xintercept = "7", linetype = "dashed", color = "black") +
  geom_vline(xintercept = "11", linetype = "dashed", color = "black") +
  geom_vline(xintercept = "26", linetype = "dashed", color = "black") +
  geom_vline(xintercept = "30", linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
  #facet_wrap(~ID) +
  labs(title = "Percentage Accuracy during Categorisation Learning", x = "Stimulus", y = "Accuracy (%)", fill= "Task") +
  scale_color_manual(values = c( "#EBA07EFF","#A8554EFF")) +
  theme_apa()+
  theme(legend.title = element_text("Task"), legend.position = "right")+
  coord_cartesian(ylim = c(0.25,1))
plot_l_cat_stim
ggsave('plot_stiml_cat.jpg', plot_l_cat_stim, width = 8, height = 8, dpi = 300)

#Final dataset
learning_finaldata_excl_filtered$accuracy <- learning_finaldata_excl_filtered$accuracy*100
learning_finaldata_excl_filtered <- merge(demographics, learning_finaldata_excl_filtered,  by = c('ID'))
learning_finaldata_excl_filtered$exp <- "78_block"
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\vibration\\vibration_cat_shape78_Block\\df")
write.csv(learning_finaldata_excl_filtered, "learning_dataset_78_B.csv", row.names = FALSE)

###TEST###
#test - shape_static
names(vibration_data)
cols_testshape<- c("participant", "category_test", "exemplar_test", "shape_percentage", "stim_test","vibration1_test", "test_resp_s.response", "test_resp_s.rt","s_loop.thisN")
shape_data <- vibration_data[cols_testshape]
shape_data <- shape_data[!duplicated(shape_data), ]
shape_data <- shape_data[complete.cases(shape_data),]
shape_data$participant <- as.factor(shape_data$participant)
levels(shape_data$participant)  
shape_data$task <- "shape_only"
colnames(shape_data)[1] <- 'ID'
colnames(shape_data)[2] <- 'category'
colnames(shape_data)[3] <- 'exemplar'
colnames(shape_data)[5] <- 'stim'
colnames(shape_data)[6] <- 'vibration_type'
colnames(shape_data)[7] <- 'response'
colnames(shape_data)[8] <- 'RTms'
colnames(shape_data)[9] <- 'trial_n'
shape_data$RTms <- shape_data$RTms*1000
shape_data$corrAns <-  ifelse(shape_data$category == "category_A", "A","B")
shape_data$accuracy <-  ifelse(shape_data$corrAns == shape_data$response, 1,0)
shape_data$vibration_type <- as.factor(shape_data$vibration_type)
levels(shape_data$vibration_type)<- c("None","None","None","None")
levels(shape_data$vibration_type)
shape_data$trial_n <- shape_data$trial_n +1 
#clean dataset
cols_shape_data.b<- c("ID", "task", "category", "exemplar", "shape_percentage","stim",'vibration_type',"trial_n", "accuracy","RTms") 
shape_data<- shape_data[cols_shape_data.b]
shape_data$category<- as.factor(shape_data$category)
shape_data$exemplar<- as.factor(shape_data$exemplar)
shape_data$stim<- as.factor(shape_data$stim)
shape_data$vibration_type<- as.factor(shape_data$vibration_type)
shape_data$shape_percentage<- as.factor(shape_data$shape_percentage)
levels(shape_data$shape_percentage) <- c("100%","22%", "78%")
shape_data$trial_n<- as.factor(shape_data$trial_n)

#test - motion
names(vibration_data)
cols_testshape_motion<- c("participant", "category_test", "exemplar_test", "shape_percentage", "stim_test","vibration1_test", "test_resp_sm.response", "test_resp_sm.rt","sm_loop.thisN")
motion_data <- vibration_data[cols_testshape_motion]
motion_data <- motion_data[!duplicated(motion_data), ]
motion_data <- motion_data[complete.cases(motion_data),]
motion_data$participant <- as.factor(motion_data$participant)
levels(motion_data$participant)  
motion_data$task <- "shape_motion"
colnames(motion_data)[1] <- 'ID'
colnames(motion_data)[2] <- 'category'
colnames(motion_data)[3] <- 'exemplar'
colnames(motion_data)[5] <- 'stim'
colnames(motion_data)[6] <- 'vibration_type'
colnames(motion_data)[7] <- 'response'
colnames(motion_data)[8] <- 'RTms'
colnames(motion_data)[9] <- 'trial_n'
motion_data$RTms <- motion_data$RTms*1000
motion_data$corrAns <-  ifelse(motion_data$category == "category_A", "A","B")
motion_data$accuracy <-  ifelse(motion_data$corrAns == motion_data$response, 1,0)
motion_data$trial_n <- motion_data$trial_n +1 
#clean dataset
cols_motion_data.b<- c("ID", "task", "category", "exemplar","shape_percentage",  "stim",'vibration_type', "trial_n","accuracy","RTms") 
motion_data<- motion_data[cols_motion_data.b]
motion_data$category<- as.factor(motion_data$category)
motion_data$exemplar<- as.factor(motion_data$exemplar)
motion_data$stim<- as.factor(motion_data$stim)
motion_data$vibration_type<- as.factor(motion_data$vibration_type)
motion_data$shape_percentage<- as.factor(motion_data$shape_percentage)
levels(motion_data$shape_percentage) <- c("100%","22%", "78%")
motion_data$trial_n<- as.factor(motion_data$trial_n)

#test - shape_static + haptic
names(vibration_data)
cols_disc2<- c("participant", "category_test", "exemplar_test", "shape_percentage", "stim_test","vibration1_test", "test_resp_sh.response", "test_resp_sh.rt","sh_loops.thisN")
shape_vibration_data <- vibration_data[cols_disc2]
shape_vibration_data <- shape_vibration_data[!duplicated(shape_vibration_data), ]
shape_vibration_data <- shape_vibration_data[complete.cases(shape_vibration_data),]
shape_vibration_data$participant <- as.factor(shape_vibration_data$participant)
levels(shape_vibration_data$participant)  
shape_vibration_data$task <- "shape_haptic"
colnames(shape_vibration_data)[1] <- 'ID'
colnames(shape_vibration_data)[2] <- 'category'
colnames(shape_vibration_data)[3] <- 'exemplar'
colnames(shape_vibration_data)[5] <- 'stim'
colnames(shape_vibration_data)[6] <- 'vibration_type'
colnames(shape_vibration_data)[7] <- 'response'
colnames(shape_vibration_data)[8] <- 'RTms'
colnames(shape_vibration_data)[9] <- 'trial_n'
shape_vibration_data$RTms <- shape_vibration_data$RTms*1000
shape_vibration_data$corrAns <-  ifelse(shape_vibration_data$category == "category_A", "A","B")
shape_vibration_data$accuracy <-  ifelse(shape_vibration_data$corrAns == shape_vibration_data$response, 1,0)
shape_vibration_data$trial_n <- shape_vibration_data$trial_n +1 

#clean dataset
cols_shape_vibration_data.b<- c("ID", "task", "category", "exemplar","shape_percentage", "stim",'vibration_type', "trial_n","accuracy","RTms") 
shape_vibration_data<- shape_vibration_data[cols_shape_vibration_data.b]
shape_vibration_data$category<- as.factor(shape_vibration_data$category)
shape_vibration_data$exemplar<- as.factor(shape_vibration_data$exemplar)
shape_vibration_data$stim<- as.factor(shape_vibration_data$stim)
shape_vibration_data$vibration_type<- as.factor(shape_vibration_data$vibration_type)
shape_vibration_data$shape_percentage<- as.factor(shape_vibration_data$shape_percentage)
levels(shape_vibration_data$shape_percentage) <- c("100%","22%", "78%")
shape_vibration_data$trial_n<- as.factor(shape_vibration_data$trial_n)

#test - motion + haptic
names(vibration_data)
cols_testshape<- c("participant", "category_test", "exemplar_test","shape_percentage", "stim_test","vibration1_test", "test_resp_smh.response", "test_resp_smh.rt","smh_loop.thisN")
motion_vibration_data <- vibration_data[cols_testshape]
motion_vibration_data <- motion_vibration_data[!duplicated(motion_vibration_data), ]
motion_vibration_data <- motion_vibration_data[complete.cases(motion_vibration_data),]
motion_vibration_data$participant <- as.factor(motion_vibration_data$participant)
levels(motion_vibration_data$participant)  
motion_vibration_data$task <- "motion_vibration"
colnames(motion_vibration_data)[1] <- 'ID'
colnames(motion_vibration_data)[2] <- 'category'
colnames(motion_vibration_data)[3] <- 'exemplar'
colnames(motion_vibration_data)[5] <- 'stim'
colnames(motion_vibration_data)[6] <- 'vibration_type'
colnames(motion_vibration_data)[7] <- 'response'
colnames(motion_vibration_data)[8] <- 'RTms'
colnames(motion_vibration_data)[9] <- 'trial_n'
motion_vibration_data$RTms <- motion_vibration_data$RTms*1000
motion_vibration_data$corrAns <-  ifelse(motion_vibration_data$category == "category_A", "A","B")
motion_vibration_data$accuracy <-  ifelse(motion_vibration_data$corrAns == motion_vibration_data$response, 1,0)
motion_vibration_data$trial_n <- motion_vibration_data$trial_n +1 

#clean dataset
cols_motion_vibration_data.b<- c("ID", "task", "category", "exemplar", "shape_percentage", "stim",'vibration_type',"trial_n","accuracy","RTms") 
motion_vibration_data<- motion_vibration_data[cols_motion_vibration_data.b]
motion_vibration_data$category<- as.factor(motion_vibration_data$category)
motion_vibration_data$exemplar<- as.factor(motion_vibration_data$exemplar)
motion_vibration_data$stim<- as.factor(motion_vibration_data$stim)
motion_vibration_data$vibration_type<- as.factor(motion_vibration_data$vibration_type)
motion_vibration_data$shape_percentage<- as.factor(motion_vibration_data$shape_percentage)
levels(motion_vibration_data$shape_percentage) <- c("100%","22%", "78%")
motion_vibration_data$trial_n<- as.factor(motion_vibration_data$trial_n)

test_data <- rbind(shape_data, shape_vibration_data, motion_data, motion_vibration_data)

# List of IDs to exclude
exclude_ids <- c( "6630d342e33ca32f75561f05")
# Exclude these IDs from the original dataset
test_data_filtered <- test_data %>%
  filter(!ID %in% exclude_ids)

# View the filtered dataset
test_data_filtered <- test_data
test_data_filtered
table(test_data_filtered$ID)
test_data_filtered$task <- as.factor(test_data_filtered$task)
levels(test_data_filtered$task) <- c("Shape Motion Haptic","Shape Haptic", "Shape Motion" ,"Shape")
levels(test_data_filtered$exemplar) <- c("Learned", "Not learned")
test_data_filtered$accuracy <- test_data_filtered$accuracy*100

test_data_filtered <- merge(demographics, test_data_filtered,  by = c('ID'))
test_data_filtered$exp <- "78_block"
write.csv(test_data_filtered, "test_filtered_dataset_78_B.csv", row.names = FALSE)

plot_test <-  ggplot(data = test_data_filtered, aes(x = task, y = accuracy, col = exemplar, group = exemplar)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  geom_hline(yintercept = 75, linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
 # facet_wrap(~ID) +
  labs(title = "Percentage Accuracy during Test", x = "Cue Condition", y = "Accuracy (%)", fill= "Exemplar") +
  scale_color_manual(values = c( "indianred4","cornflowerblue")) +
  theme_apa()+
  coord_cartesian(ylim = c(0,100))+
  theme(legend.title = element_text("Task"), legend.position = "top")
plot_test

#Remove outliers - exclusion criteria- RTs and cut off 
#a - GROUP cut_off - at least 3 SDs above the mean 
test_data_filtered_RT<- test_data_filtered
upper_cut_off <- mean(test_data_filtered_RT$RTms) + 2.5*(sd(test_data_filtered_RT$RTms))
lower_cut_off <- mean(test_data_filtered_RT$RTms) - 2.5*(sd(test_data_filtered_RT$RTms))
d_groupcutoff<- subset(test_data_filtered_RT, RTms < upper_cut_off & RTms > lower_cut_off)
test_data_filtered_RT$outlier_RT <- ifelse(test_data_filtered_RT$RTms > upper_cut_off |
                             test_data_filtered_RT$RTms < lower_cut_off, 'Yes', 'No')
table(test_data_filtered_RT$outlier_RT)
test_data_filtered_RT_noGroupoutliers <- subset(test_data_filtered_RT, outlier_RT == 'No')
#b - INDIVIDUAL cut-off - 4 SDs above the individual mean
test_data_filtered_RT_Indcutoff <- test_data_filtered_RT_noGroupoutliers %>% group_by(ID) %>%
  filter(RTms < mean(RTms) + (4 * sd(RTms)), RTms > mean(RTms) - (4 * sd(RTms)))
boxplot(test_data_filtered_RT_Indcutoff$RTms)
hist(test_data_filtered_RT_Indcutoff$RTms)
range(test_data_filtered_RT_Indcutoff$RTms)
#c - check people with RT below 500 ms 
d_below500 <- subset(test_data_filtered_RT_noGroupoutliers, RTms < 250) 
summary(d_below500)
#final dataset -with no outliers
test_data_noout_RT <- subset(test_data_filtered_RT_noGroupoutliers, RTms > 250)

test_dataRT_filtered <- merge(demographics, test_data_noout_RT,  by = c('ID'))
write.csv(test_dataRT_filtered, "RTtest_filtered_dataset_78_B.csv", row.names = FALSE)

plot_test_RTs <-  ggplot(data = test_data_noout_RT, aes(x = task, y = RTms, col = exemplar, group = exemplar)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  #facet_wrap(~ID) +
  labs(title = "Reaction Times during Test", x = "Cue Condition", y = "Reaction Times (ms)", fill= "Exemplar") +
  fll_color_manual(values = c( "indianred4","cornflowerblue")) +
  theme_apa()+
  coord_cartesian(ylim = c(750,2250))+
  theme(legend.title = element_text("Task"), legend.position = "top")
plot_test_RTs

plot_test_2 <-  ggplot(data = test_data_filtered, aes(x = vibration_type, y = accuracy, col = exemplar, group = exemplar)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  geom_hline(yintercept = 80, linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
#  facet_wrap(~task) +
  labs(title = "Percentage Accuracy during Test", x = "Cue Condition", y = "Accuracy (%)", fill= "Exemplar") +
  scale_color_manual(values = c( "indianred4","cornflowerblue")) +
  theme_apa()+
  coord_cartesian(ylim = c(0,100))+
  theme(legend.title = element_text("Task"), legend.position = "top")
plot_test_2

ggsave('plot_test.jpg', plot_test, width = 9, height = 6, dpi = 300)
ggsave('plot_test_RT.jpg', plot_test_RTs, width = 8, height = 6, dpi = 300)
ggsave('plot_test_motiontype.jpg', plot_test_2, width = 8, height = 6, dpi = 300)
ggsave('plot_test_individual.jpg', plot_test, width = 12, height = 8, dpi = 300)

#Category percentage - 78/22
levels(test_data_filtered$shape_percentage) <- c("Novel Informative", "Learned Uninformative", "Learned Informative")
colnames(test_data_filtered)[5] <- "Shape_Informativeness"
test_dataSHAPEPERC_filtered <- merge(demographics, test_data_filtered,  by = c('ID'))
write.csv(test_dataSHAPEPERC_filtered, "test_dataSHAPEPERC_dataset_78_B.csv", row.names = FALSE)

plot_cat_p22<-  ggplot(data = test_data_filtered, aes(x = task, y = accuracy, col = Shape_Informativeness, group = Shape_Informativeness)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  #stat_summary(geom = 'line', alpha = 0.9, linewidth = 1) +
  geom_hline(yintercept = 75, linetype = "dashed", color = "black") +
  geom_hline(yintercept = 50, linetype = "dashed", color = "black") +
#  facet_wrap(~Shape_Informativeness) +
  labs(title = "Percentage Accuracy during Categorisation Test", x = "Cue Condition", y = "Accuracy (%)", fill= "Task") +
  scale_color_manual(values = c("olivedrab4", "#A8554EFF", "blue4")) +
  theme_apa()+
  coord_cartesian(ylim = c(0,100))+
  theme(legend.title = element_text("Task"), legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.direction = "vertical")
plot_cat_p22

levels(test_data_filtered$task)
test_shape<- subset(test_data_filtered, task == "Shape")
test_sm<- subset(test_data_filtered, task == "Shape Motion")
test_sh<- subset(test_data_filtered, task == "Shape Haptic")
test_shm<- subset(test_data_filtered, task == "Shape Motion Haptic")

plot_l_cat_stim<-  ggplot(data = test_data_filtered, aes(x = stim, y = accuracy, col = Shape_Informativeness, group = Shape_Informativeness)) +
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 0.7) +
  # stat_summary(geom = 'line', alpha = 0.9, linewidth = 1) +
  geom_hline(yintercept = 75, linetype = "dashed", color = "black") +
  geom_vline(xintercept = "7", linetype = "dashed", color = "black") +
  geom_vline(xintercept = "11", linetype = "dashed", color = "black") +
  geom_vline(xintercept = "26", linetype = "dashed", color = "black") +
  geom_vline(xintercept = "30", linetype = "dashed", color = "black") +
  #stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.5) +
 #facet_wrap(~task) +
  labs(title = "Percentage Accuracy during Categorisation Test", x = "Stimulus", y = "Accuracy (%)", fill= "Task") +
  scale_color_manual(values = c("olivedrab4", "#A8554EFF", "blue4")) +
  theme_apa()+
  coord_cartesian(ylim = c(0,100))+
  theme(legend.title = element_text("Task"), legend.position = "top")
plot_l_cat_stim

ggsave('plot_test_cat.jpg', plot_cat_p22, width = 10, height = 8, dpi = 300)
ggsave('plot_stim_test_cat.jpg', plot_l_cat_stim, width = 8, height = 5, dpi = 300)
ggsave('plot_stimtasak_test_cat.jpg', plot_l_cat_stim, width = 13, height = 10, dpi = 300)

